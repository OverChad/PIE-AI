"""
FastAPI Web Server for P.I.E AI Dashboard
"""

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import uvicorn
import json
import asyncio
from datetime import datetime
from pathlib import Path
import sys

sys.path.append(str(Path(__file__).parent.parent))

from core.database import Database
from core.monitor import ActivityMonitor
from core.ai_analyzer import AIAnalyzer
from core.notifier import send_distraction_toast

try:
    import win32gui
    import win32con
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False


# Global variables
db = Database()
monitor = None
ai_analyzer = None
active_task_id = None
_main_loop: Optional[asyncio.AbstractEventLoop] = None
active_connections: List[WebSocket] = []


# Pydantic models
class TaskCreate(BaseModel):
    title: str
    description: str
    estimated_duration: Optional[int] = None


class TaskUpdate(BaseModel):
    status: str


class SettingsUpdate(BaseModel):
    api_key: Optional[str] = None
    check_interval: Optional[int] = 5
    notification_enabled: Optional[bool] = True
    auto_close_tab: Optional[bool] = None


def init_api_key_from_config():
    """
    Load API key from config.json and always sync it to DB.
    config.json is the source of truth - it overwrites whatever is in the DB.
    """
    config_file = Path(__file__).parent.parent / 'config.json'
    if not config_file.exists():
        return

    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            key = data.get('api_key', '').strip()

        placeholder_keys = {
            'YOUR_GROQ_API_KEY_HERE',
            'YOUR_GEMINI_API_KEY_HERE',
            '',
        }

        if key and key not in placeholder_keys:
            # Always write - this ensures a freshly rotated key in config.json
            # replaces any stale key that was cached in the DB.
            db.set_setting('api_key', key)
            print(f"API key loaded from config.json ({key[:8]}...")
        else:
            print("WARNING: config.json has no valid API key - set api_key in config.json")
    except Exception as e:
        print(f"WARNING: Could not load API key from config.json: {e}")


def restore_active_session():
    """Restore active task and AI context on server restart"""
    global ai_analyzer, active_task_id
    active_task = db.get_active_task()
    if not active_task:
        return
    active_task_id = active_task['id']
    api_key = db.get_setting('api_key')
    if not api_key:
        print("WARNING: No API key found - AI features disabled")
        return
    try:
        ai_analyzer = AIAnalyzer(api_key=api_key)
        if active_task.get('ai_context'):
            ai_analyzer.task_context_cache = active_task['ai_context']
            print(f"OK: Resumed AI context for task: \"{active_task['title']}\"")
        else:
            ai_analyzer.analyze_task_description(active_task['description'])
    except Exception as e:
        print(f"WARN: Could not restore AI session: {e}")


def on_activity_detected(activity_info: dict):
    """Callback when activity is detected by monitor"""
    global ai_analyzer, active_task_id, _main_loop

    # Skip if no active task
    if not active_task_id:
        return

    # ── Always-block list: override AI, block immediately ────────────────────
    proc_lower = activity_info.get('process', '').lower()
    always_block_raw = db.get_setting('always_block_list', '[]')
    try:
        always_block_list = json.loads(always_block_raw)
    except Exception:
        always_block_list = []

    if any(blocked in proc_lower for blocked in always_block_list):
        result = {
            "is_distraction": True,
            "confidence": 1.0,
            "reason": f"'{activity_info.get('process', '')}' is in your Always Block list",
            "action": "block",
            "verdict": f"{activity_info.get('process', '')} — always blocked!"
        }
    # ─────────────────────────────────────────────────────────────────────────

    # If AI is available, analyze the activity
    elif ai_analyzer:
        result = ai_analyzer.check_activity_relevance(
            current_activity=activity_info.get('process', ''),
            window_title=activity_info.get('title', ''),
            url=activity_info.get('url')
        )
    else:
        # Fallback: log without AI analysis
        result = {
            "is_distraction": False,
            "confidence": 0.0,
            "reason": "AI not available",
            "action": "allow",
            "verdict": "Activity logged (AI unavailable)"
        }

    log_id = db.log_activity(
        task_id=active_task_id,
        process_name=activity_info.get('process', ''),
        window_title=activity_info.get('title', ''),
        url=activity_info.get('url'),
        is_distraction=result.get('is_distraction', False),
        ai_confidence=result.get('confidence', 0.0),
        ai_reason=result.get('reason', '')
    )

    # If AI flagged this as distraction - send event to browser via WebSocket
    is_warning = result.get('action') in ['warn', 'block']

    # ── Windows native toast notification (bottom-right corner) ──────────────
    if is_warning:
        notif_enabled = db.get_setting('notification_enabled', 'true') == 'true'
        if notif_enabled:
            send_distraction_toast(
                verdict=result.get('verdict', 'Distraction detected!'),
                reason=result.get('reason', ''),
                app_name=activity_info.get('process', ''),
                action=result.get('action', 'warn'),
            )
    # ─────────────────────────────────────────────────────────────────────────

    # Debug logging
    print(f"\n{'='*60}")
    print(f"ACTIVITY DETECTED:")
    print(f"  Process: {activity_info.get('process', 'N/A')}")
    print(f"  Title: {activity_info.get('title', 'N/A')[:50]}")
    print(f"  URL: {activity_info.get('url', 'N/A')}")
    print("AI VERDICT:")
    print(f"  is_distraction: {result.get('is_distraction')}")
    print(f"  action: {result.get('action')}")
    print(f"  confidence: {result.get('confidence'):.0%}")
    print(f"  verdict: {result.get('verdict', 'N/A')}")
    print(f"WILL SHOW WARNING: {is_warning}")
    print(f"  WebSocket connections: {len(active_connections)}")
    print(f"{'='*60}\n")

    broadcast_data = {
        "type": "activity_update",
        "activity": activity_info,
        "analysis": result,
        "log_id": log_id,
        # Flag for frontend: show warning overlay
        "show_warning": is_warning,
        "focus_dashboard": is_warning,
    }

    if _main_loop and not _main_loop.is_closed():
        asyncio.run_coroutine_threadsafe(
            broadcast_activity(broadcast_data), _main_loop
        )
    else:
        print("WARNING: Event loop not available - cannot send WebSocket message")




async def broadcast_activity(activity_data: dict):
    """Broadcast activity to all connected WebSocket clients"""
    dead = []
    for conn in active_connections:
        try:
            await conn.send_json(activity_data)
        except Exception:
            dead.append(conn)
    for conn in dead:
        if conn in active_connections:
            active_connections.remove(conn)


def create_app():
    """Create and configure FastAPI application"""
    app = FastAPI(title="P.I.E AI", description="Procrastination Is Escaped")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Initialize
    init_api_key_from_config()
    restore_active_session()

    # ── Seed default always-block list (social media) on first run ────────────
    DEFAULT_ALWAYS_BLOCK = [
        'whatsapp.exe',
        'telegram.exe',
        'discord.exe',
        'spotify.exe',
        'steam.exe',
        'epicgameslauncher.exe',
        'tiktok.exe',
        'instagram.exe',
        'vk.exe',
        'viber.exe',
        'slack.exe',
    ]
    if db.get_setting('always_block_seeded') != 'true':
        existing_raw = db.get_setting('always_block_list', '[]')
        try:
            existing = json.loads(existing_raw)
        except Exception:
            existing = []
        merged = list(dict.fromkeys(existing + DEFAULT_ALWAYS_BLOCK))
        db.set_setting('always_block_list', json.dumps(merged))
        db.set_setting('always_block_seeded', 'true')
        print(f"[PIE] Default always-block list seeded ({len(DEFAULT_ALWAYS_BLOCK)} apps)")
    # ─────────────────────────────────────────────────────────────────────────

    @app.get("/")
    async def root():
        """Serve main HTML page"""
        html_path = Path(__file__).parent / "templates" / "index.html"
        if html_path.exists():
            return FileResponse(html_path)
        return {"message": "Frontend not found"}

    @app.get("/test")
    async def test_overlay():
        """Test page for warning overlay"""
        html_path = Path(__file__).parent / "templates" / "test_overlay.html"
        if html_path.exists():
            return FileResponse(html_path)
        return {"message": "Test page not found"}

    @app.get("/api/status")
    async def get_status():
        """Get current monitoring status"""
        active_task = db.get_active_task()
        current_activity = monitor.get_current_activity() if monitor and monitor.running else None
        return {
            "monitor_running": monitor.running if monitor else False,
            "ai_enabled": ai_analyzer is not None and (ai_analyzer.ai_available if hasattr(ai_analyzer, 'ai_available') else True),
            "active_task": active_task,
            "current_activity": current_activity,
            "timestamp": datetime.now().isoformat()
        }

    @app.post("/api/tasks")
    async def create_task(task: TaskCreate):
        """Create new task"""
        global ai_analyzer, active_task_id, monitor

        api_key = db.get_setting('api_key')
        
        # Try to create AI analyzer (may work in fallback mode)
        try:
            ai_analyzer = AIAnalyzer(api_key=api_key)
            ai_context = ai_analyzer.analyze_task_description(task.description)
        except Exception as e:
            print(f"WARNING: AI analyzer initialization failed: {e}")
            ai_context = None

        task_id = db.create_task(
            title=task.title,
            description=task.description,
            ai_context=ai_context,
            estimated_duration=task.estimated_duration
        )
        active_task_id = task_id

        # Start monitor if not running
        if not monitor or not monitor.running:
            monitor = ActivityMonitor(
                callback=on_activity_detected,
                check_interval=int(db.get_setting('check_interval', '5'))
            )
            monitor.start()

        return {"task_id": task_id, "ai_context": ai_context, "status": "created"}

    @app.get("/api/tasks")
    async def get_tasks():
        """Get all tasks"""
        return {"tasks": db.get_all_tasks()}

    @app.get("/api/tasks/{task_id}")
    async def get_task(task_id: int):
        """Get specific task"""
        task = db.get_task(task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        return task

    @app.put("/api/tasks/{task_id}")
    async def update_task(task_id: int, update: TaskUpdate):
        """Update task status"""
        global monitor
        db.update_task_status(task_id, update.status)
        if update.status == "completed" and monitor:
            monitor.stop()
        return {"status": "updated"}

    @app.post("/api/tasks/{task_id}/activate")
    async def activate_task(task_id: int):
        """Activate a task and start monitoring"""
        global active_task_id, monitor
        
        task = db.get_task(task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        # Deactivate all other tasks
        for t in db.get_all_tasks():
            if t['id'] != task_id and t['status'] == 'active':
                db.update_task_status(t['id'], 'pending')
        
        # Activate selected task
        db.update_task_status(task_id, 'active')
        active_task_id = task_id
        
        # Start monitoring if not running
        if monitor and not monitor.running:
            await start_monitoring()
        
        return {"status": "activated", "task_id": task_id}

    @app.post("/api/tasks/{task_id}/stop")
    async def stop_task(task_id: int):
        """Stop a task"""
        global monitor, active_task_id
        
        task = db.get_task(task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        db.update_task_status(task_id, 'pending')
        
        if active_task_id == task_id:
            active_task_id = None
            if monitor:
                monitor.stop()
        
        return {"status": "stopped", "task_id": task_id}

    @app.post("/api/tasks/{task_id}/delete")
    async def delete_task(task_id: int):
        """Delete a task"""
        global active_task_id, monitor
        
        task = db.get_task(task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")
        
        # Stop monitoring if this is the active task
        if active_task_id == task_id:
            active_task_id = None
            if monitor:
                monitor.stop()
        
        # Delete task from database
        db.delete_task(task_id)
        
        return {"status": "deleted", "task_id": task_id}

    @app.get("/api/activity")
    async def get_activity_log(task_id: Optional[int] = None, limit: int = 100):
        """Get activity log"""
        all_entries = db.get_activity_log(task_id=task_id, limit=limit)
        return {"activities": all_entries}

    @app.get("/api/stats")
    async def get_statistics(task_id: Optional[int] = None):
        """Get productivity statistics"""
        stats = db.get_productivity_stats(task_id=task_id)
        # Add AI status
        stats['ai_available'] = ai_analyzer is not None and (ai_analyzer.ai_available if hasattr(ai_analyzer, 'ai_available') else True)
        return stats

    @app.post("/api/settings")
    async def update_settings(settings: SettingsUpdate):
        """Update settings"""
        global ai_analyzer
        if settings.api_key:
            db.set_setting('api_key', settings.api_key)
            # Re-initialize AI analyzer with new key
            try:
                ai_analyzer = AIAnalyzer(api_key=settings.api_key)
            except:
                ai_analyzer = None
        if settings.check_interval:
            db.set_setting('check_interval', str(settings.check_interval))
        if settings.notification_enabled is not None:
            db.set_setting('notification_enabled', str(settings.notification_enabled))
        if settings.auto_close_tab is not None:
            db.set_setting('auto_close_tab', str(settings.auto_close_tab))
        return {"status": "updated"}

    @app.get("/api/settings")
    async def get_settings():
        """Get settings"""
        return {
            "api_key_set": bool(db.get_setting('api_key')),
            "check_interval": int(db.get_setting('check_interval', '5')),
            "notification_enabled": db.get_setting('notification_enabled', 'true') == 'true',
            "auto_close_tab": db.get_setting('auto_close_tab', 'false') == 'True'
        }

    class PopupResponse(BaseModel):
        log_id: Optional[int] = None
        action: str  # 'allow' or 'block'

    @app.post("/api/popup/respond")
    async def popup_respond(body: PopupResponse):
        """
        Handle user response from web distraction popup.
        action: 'allow' = I know what I'm doing, 'block' = get back to work
        """
        log_id = body.log_id
        action = body.action

        if log_id:
            activities = db.get_activity_log(limit=50)
            matched = next((a for a in activities if a.get('id') == log_id), None)
            if action == "allow" and ai_analyzer and matched:
                ai_analyzer.add_user_exception(
                    app=matched.get('process_name', ''),
                    url=matched.get('url')
                )
                db.log_user_feedback(log_id, 'allow', matched)
                # Auto-remove from always-block list so exception actually takes effect
                proc = matched.get('process_name', '').lower()
                if proc:
                    ab = _get_always_block_list()
                    ab_new = [x for x in ab if x not in proc and proc not in x]
                    if len(ab_new) != len(ab):
                        _save_always_block_list(ab_new)
                        print(f"[PIE] Removed '{proc}' from always-block (user allowed it)")
            elif action == "block" and matched:
                db.log_user_feedback(log_id, 'block', matched)

        return {"status": "ok", "action": action}

    class CloseWindowBody(BaseModel):
        window_title: str
        process_name: Optional[str] = None

    @app.post("/api/close-window")
    async def close_window(body: CloseWindowBody):
        """
        Close a specific browser tab via Chrome DevTools Protocol (CDP).
        Falls back to WM_CLOSE on the matching HWND if CDP is unavailable.
        Skips apps that are in the auto-close whitelist.
        """
        import urllib.request

        title_query = (body.window_title or "").strip()
        proc_query_raw = (body.process_name or "").lower().strip()

        # ── Whitelist check: never close whitelisted apps ──────────────────
        autoclose_wl = _get_autoclose_whitelist()
        # Also always protect browsers by default (unless explicitly removed from whitelist
        # protection is opt-in: we only protect browsers if they are in the whitelist
        # OR if they weren't added to whitelist but are known browsers)
        all_protected = set(autoclose_wl)

        if proc_query_raw and any(p in proc_query_raw for p in all_protected):
            return {
                "status": "skipped",
                "reason": f"'{proc_query_raw}' is in the auto-close whitelist"
            }
        # ──────────────────────────────────────────────────────────────────

        # --- Strategy 1: CDP (closes only the matching tab, not the whole browser) ---
        cdp_ports = [9222, 9223, 9224]
        for port in cdp_ports:
            try:
                url = f"http://127.0.0.1:{port}/json"
                req = urllib.request.urlopen(url, timeout=1)
                tabs = json.loads(req.read().decode())
                for tab in tabs:
                    tab_title = tab.get("title", "")
                    tab_url   = tab.get("url", "")
                    if (title_query.lower() in tab_title.lower() or
                            title_query.lower() in tab_url.lower()):
                        ws_id = tab.get("id")
                        close_url = f"http://127.0.0.1:{port}/json/close/{ws_id}"
                        urllib.request.urlopen(close_url, timeout=2)
                        return {"status": "closed", "method": "cdp", "tab": tab_title}
            except Exception:
                continue

        # --- Strategy 2: Win32 WM_CLOSE on matching HWND ---
        if not HAS_WIN32:
            return {"status": "error", "message": "CDP unavailable and win32 not installed"}

        import win32process
        import psutil

        proc_query = proc_query_raw
        closed = []

        def enum_handler(hwnd, _):
            if not win32gui.IsWindowVisible(hwnd):
                return
            wnd_title = win32gui.GetWindowText(hwnd)
            if not wnd_title:
                return
            match = False
            if proc_query:
                try:
                    _, pid = win32process.GetWindowThreadProcessId(hwnd)
                    match = proc_query in psutil.Process(pid).name().lower()
                except Exception:
                    pass
            elif title_query:
                match = title_query.lower() in wnd_title.lower()
            if match:
                win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                closed.append(wnd_title)

        win32gui.EnumWindows(enum_handler, None)

        if closed:
            return {"status": "closed", "method": "win32", "windows": closed}
        return {"status": "not_found",
                "hint": "Start Chrome with --remote-debugging-port=9222 for tab-level close"}

    # ── Auto-close whitelist (apps that should NEVER be auto-closed) ──────────

    BROWSER_PROCESSES = {
        'chrome.exe', 'firefox.exe', 'msedge.exe', 'opera.exe',
        'brave.exe', 'safari.exe', 'vivaldi.exe', 'arc.exe',
    }

    def _get_autoclose_whitelist() -> list:
        raw = db.get_setting('autoclose_whitelist', '[]')
        try:
            return json.loads(raw)
        except Exception:
            return []

    def _save_autoclose_whitelist(lst: list):
        db.set_setting('autoclose_whitelist', json.dumps(lst))

    @app.get("/api/autoclose-whitelist")
    async def get_autoclose_whitelist():
        """Return the list of apps protected from auto-close."""
        return {"whitelist": _get_autoclose_whitelist()}

    class AutoCloseWhitelistItem(BaseModel):
        process_name: str

    @app.post("/api/autoclose-whitelist/add")
    async def add_autoclose_whitelist(item: AutoCloseWhitelistItem):
        """Add an app to the auto-close whitelist (it won't be force-closed)."""
        name = item.process_name.strip().lower()
        if not name:
            raise HTTPException(status_code=400, detail="process_name is required")
        lst = _get_autoclose_whitelist()
        if name not in lst:
            lst.append(name)
            _save_autoclose_whitelist(lst)
        return {"status": "added", "whitelist": lst}

    @app.post("/api/autoclose-whitelist/remove")
    async def remove_autoclose_whitelist(item: AutoCloseWhitelistItem):
        """Remove an app from the auto-close whitelist."""
        name = item.process_name.strip().lower()
        lst = _get_autoclose_whitelist()
        lst = [x for x in lst if x != name]
        _save_autoclose_whitelist(lst)
        return {"status": "removed", "whitelist": lst}

    # ─────────────────────────────────────────────────────────────────────────

    # ── Always-block list (apps blocked regardless of AI verdict) ─────────────

    def _get_always_block_list() -> list:
        raw = db.get_setting('always_block_list', '[]')
        try:
            return json.loads(raw)
        except Exception:
            return []

    def _save_always_block_list(lst: list):
        db.set_setting('always_block_list', json.dumps(lst))

    @app.get("/api/always-block")
    async def get_always_block():
        """Return the list of apps that are always blocked."""
        return {"list": _get_always_block_list()}

    class AlwaysBlockItem(BaseModel):
        process_name: str

    @app.post("/api/always-block/add")
    async def add_always_block(item: AlwaysBlockItem):
        """Add an app to the always-block list."""
        name = item.process_name.strip().lower()
        if not name:
            raise HTTPException(status_code=400, detail="process_name is required")
        lst = _get_always_block_list()
        if name not in lst:
            lst.append(name)
            _save_always_block_list(lst)
        return {"status": "added", "list": lst}

    @app.post("/api/always-block/remove")
    async def remove_always_block(item: AlwaysBlockItem):
        """Remove an app from the always-block list."""
        name = item.process_name.strip().lower()
        lst = _get_always_block_list()
        lst = [x for x in lst if x != name]
        _save_always_block_list(lst)
        return {"status": "removed", "list": lst}

    # ─────────────────────────────────────────────────────────────────────────

    class FeedbackBody(BaseModel):
        activity_log_id: int
        action: str

    @app.post("/api/feedback")
    async def log_feedback(body: FeedbackBody):
        """Log user feedback"""
        activities = db.get_activity_log(limit=50)
        matched = next((a for a in activities if a.get('id') == body.activity_log_id), None)
        if matched:
            db.log_user_feedback(body.activity_log_id, body.action, matched)
            if ai_analyzer:
                ai_analyzer.learn_from_feedback(matched, body.action)
        return {"status": "logged"}

    @app.post("/api/monitor/start")
    async def start_monitoring():
        """Start activity monitoring"""
        global monitor, ai_analyzer, active_task_id

        # Check if we have a task
        if not active_task_id:
            active_task = db.get_active_task()
            if not active_task:
                raise HTTPException(status_code=400,
                    detail="Please create a task first.")
            active_task_id = active_task['id']
            
            # Try to initialize AI (may fail gracefully)
            api_key = db.get_setting('api_key')
            try:
                ai_analyzer = AIAnalyzer(api_key=api_key)
                if active_task.get('ai_context'):
                    ai_analyzer.task_context_cache = active_task['ai_context']
                else:
                    ai_analyzer.analyze_task_description(active_task['description'])
            except Exception as e:
                print(f"WARNING: AI initialization failed: {e}")
                # Continue anyway - will work in fallback mode

        if not monitor:
            monitor = ActivityMonitor(
                callback=on_activity_detected,
                check_interval=int(db.get_setting('check_interval', '5'))
            )
        monitor.start()
        return {"status": "started"}

    @app.post("/api/monitor/stop")
    async def stop_monitoring():
        """Stop activity monitoring"""
        global monitor
        if monitor:
            monitor.stop()
        return {"status": "stopped"}

    @app.post("/api/exceptions/clear")
    async def clear_exceptions():
        """Clear all user exceptions (reset 'I know what I'm doing' permissions)"""
        global ai_analyzer
        if ai_analyzer:
            count = ai_analyzer.clear_user_exceptions()
            return {"status": "cleared", "count": count}
        return {"status": "no_ai", "count": 0}
    
    @app.get("/api/exceptions")
    async def get_exceptions():
        """Get list of current user exceptions"""
        global ai_analyzer
        if ai_analyzer:
            return {"exceptions": ai_analyzer.get_user_exceptions()}
        return {"exceptions": []}

    class DeleteExceptionBody(BaseModel):
        index: int

    @app.post("/api/exceptions/delete")
    async def delete_exception(body: DeleteExceptionBody):
        """Delete a single exception by its index in the list"""
        global ai_analyzer
        if not ai_analyzer:
            return {"status": "error", "message": "AI not initialized"}
        exceptions = ai_analyzer.get_user_exceptions()
        if body.index < 0 or body.index >= len(exceptions):
            raise HTTPException(status_code=404, detail="Exception index out of range")
        removed = exceptions.pop(body.index)
        ai_analyzer.user_exceptions = exceptions
        return {"status": "deleted", "removed": removed, "remaining": len(exceptions)}
    
    class AddExceptionBody(BaseModel):
        app: str
        url: Optional[str] = None

    @app.post("/api/exceptions/add")
    async def add_exception(body: AddExceptionBody):
        """Manually add a new exception"""
        global ai_analyzer
        if not ai_analyzer:
            return {"status": "error", "message": "AI not initialized"}
        
        # Add to user exceptions
        ai_analyzer.add_user_exception(app=body.app, url=body.url)

        # Auto-remove from always-block list so exception actually takes effect
        proc = (body.app or '').lower()
        if proc:
            ab = _get_always_block_list()
            ab_new = [x for x in ab if x not in proc and proc not in x]
            if len(ab_new) != len(ab):
                _save_always_block_list(ab_new)
                print(f"[PIE] Removed '{proc}' from always-block (manual exception added)")

        return {
            "status": "added",
            "exception": {"app": body.app, "url": body.url},
            "total": len(ai_analyzer.get_user_exceptions())
        }
    
    @app.post("/api/stats/reset")
    async def reset_statistics():
        """Reset all statistics (Focus Score and distraction count)"""
        try:
            db.reset_statistics()
            return {"status": "success", "message": "Statistics reset successfully"}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    
    @app.post("/api/activity/clear")
    async def clear_activity_log():
        """Clear all activity log entries"""
        try:
            count = db.clear_activity_log()
            return {"status": "success", "count": count, "message": f"Cleared {count} activity entries"}
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        """WebSocket endpoint for real-time updates"""
        global _main_loop
        _main_loop = asyncio.get_event_loop()
        await websocket.accept()
        active_connections.append(websocket)
        try:
            while True:
                # Keep connection alive; client doesn't need to send anything
                await asyncio.sleep(30)
        except (WebSocketDisconnect, Exception):
            pass
        finally:
            if websocket in active_connections:
                active_connections.remove(websocket)

    # Mount static files
    static_path = Path(__file__).parent / "static"
    if static_path.exists():
        app.mount("/static", StaticFiles(directory=str(static_path)), name="static")
        app.mount("/css", StaticFiles(directory=str(static_path / "css")), name="css")
        app.mount("/js", StaticFiles(directory=str(static_path / "js")), name="js")

    return app


def run_server(host: str = "127.0.0.1", port: int = 8000):
    """Run the server"""
    app = create_app()
    print(f"Starting P.I.E AI Dashboard at http://{host}:{port}")
    print("Press Ctrl+C to stop")
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    run_server()
