//Dashboard JavaScript

const API_BASE = '';
let ws = null;
let wsReconnectTimer = null;
let currentTaskId = null;
let currentWarningData = null;
let warningTimerTimeout = null;
let _titleFlashInterval = null;
let _alertSoundInterval = null;

// Init
document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    loadStatus();
    loadSettings();
    loadAutocloseWhitelist();
    loadAlwaysBlock();
    connectWebSocket();
    setInterval(loadStatus, 15000);
    
    // Load exceptions for display on main page
    loadExceptionsQuick();
    setInterval(loadExceptionsQuick, 10000); // Update every 10 sec

    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }

    // Listen to localStorage - other tabs can request us to focus
    window.addEventListener('storage', (e) => {
        if (e.key === 'pie_focus_request') {
            window.focus();
        }
    });
});

// Tabs
function initTabs() {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });
}

function switchTab(name) {
    document.querySelectorAll('.nav-btn').forEach(b =>
        b.classList.toggle('active', b.dataset.tab === name));
    document.querySelectorAll('.tab-content').forEach(c =>
        c.classList.remove('active'));
    document.getElementById(name).classList.add('active');
    if (name === 'tasks') loadTasks();
    else if (name === 'activity') loadActivityLog();
    else if (name === 'settings') { loadExceptions(); loadAutocloseWhitelist(); loadAlwaysBlock(); }
}

// WebSocket
function connectWebSocket() {
    if (ws && ws.readyState !== WebSocket.CLOSED) {
        ws.onclose = null;
        ws.close();
    }
    clearTimeout(wsReconnectTimer);

    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${proto}//${location.host}/ws`);

    ws.onopen = () => console.log('[PIE] WebSocket connected');

    ws.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);
            console.log('[PIE] WS message:', data.type, '| show_warning:', data.show_warning);
            handleRealtimeUpdate(data);
        } catch (e) {
            console.error('[PIE] WS parse error:', e);
        }
    };

    ws.onerror = (e) => console.error('[PIE] WS error:', e);

    ws.onclose = () => {
        console.log('[PIE] WS disconnected, reconnecting in 5s...');
        wsReconnectTimer = setTimeout(connectWebSocket, 5000);
    };
}

// Realtime update handler
function handleRealtimeUpdate(data) {
    console.log('[PIE] Received data:', data);
    
    if (data.type !== 'activity_update') return;

    updateCurrentActivity(data.activity);

    // Check notification setting (enabled by default)
    const notifCheckbox = document.getElementById('notifications-enabled');
    const notifEnabled = notifCheckbox ? notifCheckbox.checked : true;

    const analysis = data.analysis || {};
    const isWarn =
        data.show_warning === true ||
        (analysis.is_distraction === true && analysis.action !== 'allow');

    console.log('[PIE] Warning check:', {
        show_warning: data.show_warning,
        is_distraction: analysis.is_distraction,
        action: analysis.action,
        isWarn: isWarn,
        notifEnabled: notifEnabled
    });

    if (isWarn) {
        if (notifEnabled) {
            console.log('[PIE] SHOWING WARNING OVERLAY!');
            focusDashboard();
            showWarningOverlay(data.activity, analysis, data.log_id);
        } else {
            console.log('[PIE] Warning skipped - notifications disabled');
        }
    } else {
        console.log('[PIE] No warning needed');
    }

    loadStats();
}

// Focus dashboard tab
function focusDashboard() {
    // 1. Attempt to switch focus via localStorage (works between tabs)
    try { localStorage.setItem('pie_focus_request', Date.now()); } catch(e) {}

    // 2. window.focus on current tab
    window.focus();

    // 3. Browser notification (on top of any window, click = go here)
    if ('Notification' in window && Notification.permission === 'granted') {
        const n = new Notification('P.I.E AI - Stop!', {
            body: 'You got distracted! Click to get back to work.',
            requireInteraction: true,
            tag: 'pie-warning'
        });
        n.onclick = () => { window.focus(); n.close(); };
    }

    // 4. Flash tab title
    flashTitle();
}

function flashTitle() {
    if (_titleFlashInterval) return; // already flashing
    const orig = document.title;
    let on = true;
    _titleFlashInterval = setInterval(() => {
        document.title = on ? 'STOP! - P.I.E AI' : orig;
        on = !on;
    }, 700);
}

function stopFlash() {
    clearInterval(_titleFlashInterval);
    _titleFlashInterval = null;
    document.title = 'P.I.E AI';
}

// Warning Overlay
function showWarningOverlay(activity, analysis, logId) {
    console.log('[PIE] showWarningOverlay called', { activity, analysis, logId });

    currentWarningData = { activity, analysis, logId: logId || null, windowTitle: activity?.title || "" };

    // Fill fields
    const taskTitle = document.getElementById('current-task-title')?.textContent || '-';
    const appLabel  = activity.process_friendly || activity.process || '-';
    const actLabel  = appLabel + (activity.url ? ' - ' + activity.url : '');

    document.getElementById('warning-verdict').textContent =
        analysis.verdict || analysis.reason || "This is not related to your task.";
    document.getElementById('warning-task-name').textContent = taskTitle;
    document.getElementById('warning-activity-name').textContent = actLabel;
    document.getElementById('warning-reason').textContent = analysis.reason || '-';

    // Confidence bar
    const pct = Math.round((analysis.confidence || 0) * 100);
    document.getElementById('confidence-pct').textContent = pct + '%';
    const bar = document.getElementById('confidence-bar');
    bar.style.width = '0%';
    bar.style.backgroundPosition = `${100 - pct}% 0`;
    requestAnimationFrame(() => { bar.style.width = pct + '%'; });

    // Update Close button label based on auto-close setting
    const autoCloseOn = document.getElementById('auto-close-tab')?.checked ?? false;
    const closeBtn = document.querySelector('.warn-btn-close');
    if (closeBtn) {
        const small = closeBtn.querySelector('small');
        const strong = closeBtn.querySelector('strong');
        if (autoCloseOn) {
            if (strong) strong.textContent = 'Close Tab / App';
            if (small)  small.textContent  = 'Force close it';
        } else {
            if (strong) strong.textContent = 'Dismiss';
            if (small)  small.textContent  = 'Auto-close is OFF';
        }
    }

    // Show overlay
    const overlay = document.getElementById('warning-overlay');
    overlay.classList.add('active');

    // Play alert sound repeatedly until dismissed
    const soundType = analysis.action === 'block' ? 'block' : 'warn';
    clearInterval(_alertSoundInterval);
    playAlertSound(soundType);                          // play immediately
    _alertSoundInterval = setInterval(() => {
        if (overlay.classList.contains('active')) {
            playAlertSound(soundType);
        } else {
            clearInterval(_alertSoundInterval);
            _alertSoundInterval = null;
        }
    }, soundType === 'block' ? 3500 : 5000);           // block = every 3.5s, warn = every 5s

    // Auto-dismiss timer 30 seconds
    clearTimeout(warningTimerTimeout);
    const timerBar = document.getElementById('timer-bar');
    timerBar.style.animation = 'none';
    void timerBar.offsetHeight; // reflow
    timerBar.style.animation = 'timerShrink 30s linear forwards';
    warningTimerTimeout = setTimeout(() => {
        if (overlay.classList.contains('active')) acknowledgeWarning();
    }, 30000);
}

function hideWarningOverlay() {
    clearTimeout(warningTimerTimeout);
    clearInterval(_alertSoundInterval);
    _alertSoundInterval = null;
    stopFlash();
    document.getElementById('warning-overlay').classList.remove('active');
}

// Button: I know what I'm doing
async function acknowledgeWarning() {
    hideWarningOverlay();
    if (currentWarningData) {
        try {
            await apiPost('/api/popup/respond', {
                log_id: currentWarningData.logId,
                action: 'allow'
            });
        } catch(e) {}
    }
    currentWarningData = null;
}

// Close distraction button - closes the window via Python/Win32
async function closeDistraction() {
    hideWarningOverlay();

    if (currentWarningData) {
        apiPost('/api/popup/respond', {
            log_id: currentWarningData.logId,
            action: 'block'
        }).catch(() => {});

        // Only close if auto-close is enabled in settings
        const autoCloseEnabled = document.getElementById('auto-close-tab')?.checked ?? false;
        if (!autoCloseEnabled) {
            showNotification('Auto-close is disabled in Settings.', 'info');
            currentWarningData = null;
            return;
        }

        // Close the distraction window via Python/Win32 using process name
        const processName = currentWarningData.activity?.process || '';
        const windowTitle = currentWarningData.windowTitle || '';
        if (processName || windowTitle) {
            try {
                const res = await apiPost('/api/close-window', {
                    window_title: windowTitle,
                    process_name: processName
                });
                if (res.status === 'closed') {
                    showNotification('Window closed.', 'success');
                } else if (res.status === 'skipped') {
                    showNotification('"' + processName + '" is in the whitelist — not closed.', 'info');
                } else if (res.status === 'not_found') {
                    showNotification('Window not found - may already be closed.', 'info');
                } else {
                    showNotification('Could not close window automatically.', 'warning');
                }
            } catch(e) {
                showNotification('Could not close window.', 'warning');
            }
        }
    }

    currentWarningData = null;
}

// Status & Stats
async function loadStatus() {
    try {
        const data = await apiGet('/api/status');

        const btn = document.getElementById('toggle-monitor');
        const st  = document.getElementById('monitor-status');
        if (data.monitor_running) {
            btn.textContent = 'Stop Monitoring';
            st.textContent = 'Running';
            st.style.color = 'var(--success)';
        } else {
            btn.textContent = 'Start Monitoring';
            st.textContent = 'Stopped';
            st.style.color = 'var(--danger)';
        }

        if (data.active_task) {
            currentTaskId = data.active_task.id;
            document.getElementById('current-task-title').textContent =
                data.active_task.title;
        } else {
            document.getElementById('current-task-title').textContent = 'No active task';
        }

        if (data.current_activity) updateCurrentActivity(data.current_activity);
        loadStats();
    } catch (e) { console.error('loadStatus error:', e); }
}

async function loadStats() {
    try {
        const s = await apiGet('/api/stats');
        document.getElementById('focus-score').textContent =
            Math.round(s.focus_score || 0) + '%';
        document.getElementById('distractions-count').textContent =
            s.distractions || 0;
    } catch(e) {}
}

function updateCurrentActivity(activity) {
    const div = document.getElementById('current-activity');
    if (!activity?.title) {
        div.innerHTML = '<p class="no-activity">No activity detected</p>';
        return;
    }
    div.innerHTML = `
        <div class="activity-item focused" style="border-radius:8px;">
            <div class="activity-info">
                <h4>${esc(activity.process_friendly || activity.process)}</h4>
                <p>${esc(activity.title)}</p>
                ${activity.url ? `<p>${esc(activity.url)}</p>` : ''}
            </div>
            <div class="activity-time">${new Date(activity.timestamp).toLocaleTimeString()}</div>
        </div>`;
}

// Tasks
function showNewTaskModal() {
    document.getElementById('task-modal').classList.add('active');
}

function closeTaskModal() {
    document.getElementById('task-modal').classList.remove('active');
    ['task-title','task-description','task-duration'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
}

async function createTask() {
    const title   = document.getElementById('task-title').value.trim();
    const desc    = document.getElementById('task-description').value.trim();
    const dur     = parseInt(document.getElementById('task-duration').value) || null;

    if (!title || !desc) { alert('Fill in title and description.'); return; }

    const btn = document.getElementById('create-task-btn');
    btn.disabled = true;
    btn.textContent = 'Analyzing...';

    try {
        await apiPost('/api/tasks', { title, description: desc, estimated_duration: dur });
        closeTaskModal();
        loadStatus();
        switchTab('dashboard');
        showNotification('Task created! AI is now watching.', 'success');
    } catch(e) {
        alert(`Error: ${e.message}`);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Create & Start';
    }
}

async function loadTasks() {
    try {
        const data = await apiGet('/api/tasks');
        const list = document.getElementById('tasks-list');
        if (!data.tasks?.length) {
            list.innerHTML = '<p class="no-data">No tasks yet. Create your first task to get started! 🚀</p>';
            return;
        }
        list.innerHTML = data.tasks.map(t => `
            <div class="task-card" data-task-id="${t.id}">
                <div class="task-header">
                    <div class="task-title-section">
                        <h3>🎯 ${esc(t.title)}</h3>
                        <span class="task-badge task-badge-${t.status.toLowerCase()}">${t.status === 'active' ? '▶️' : t.status === 'completed' ? '✅' : '⏸️'} ${t.status}</span>
                    </div>
                    <div class="task-actions">
                        ${t.status === 'active' ? 
                            `<button class="task-action-btn task-stop" onclick="stopTask(${t.id})" title="Pause task">⏸️</button>` : 
                            `<button class="task-action-btn task-start" onclick="activateTask(${t.id})" title="Resume task">▶️</button>`
                        }
                        <button class="task-action-btn task-delete" onclick="deleteTask(${t.id})" title="Delete task">🗑️</button>
                    </div>
                </div>
                <div class="task-description">
                    <p>📝 ${esc(t.description.substring(0,200))}${t.description.length>200?'...':''}</p>
                </div>
                <div class="task-meta">
                    <span class="task-meta-item">
                        <span class="meta-icon">📅</span>
                        ${new Date(t.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                    ${t.estimated_duration ? 
                        `<span class="task-meta-item">
                            <span class="meta-icon">⏱️</span>
                            ${t.estimated_duration} min
                        </span>` : ''
                    }
                    ${t.status === 'completed' && t.completed_at ? 
                        `<span class="task-meta-item task-completed-time">
                            <span class="meta-icon">✅</span>
                            Completed ${new Date(t.completed_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                        </span>` : ''
                    }
                </div>
            </div>`).join('');
    } catch(e) { 
        console.error('loadTasks:', e);
        document.getElementById('tasks-list').innerHTML = 
            '<p class="no-data error">❌ Failed to load tasks. Please refresh the page.</p>';
    }
}

// Activity Log

async function activateTask(taskId) {
    try {
        await apiPost(`/api/tasks/${taskId}/activate`, {});
        showNotification('Task activated!', 'success');
        loadTasks();
        loadStatus();
    } catch(e) {
        showNotification('Failed to activate task', 'error');
    }
}

async function stopTask(taskId) {
    try {
        await apiPost(`/api/tasks/${taskId}/stop`, {});
        showNotification('Task stopped', 'info');
        loadTasks();
        loadStatus();
    } catch(e) {
        showNotification('Failed to stop task', 'error');
    }
}

async function deleteTask(taskId) {
    if (!confirm('Are you sure you want to delete this task? This action cannot be undone.')) {
        return;
    }
    
    try {
        await apiPost(`/api/tasks/${taskId}/delete`, {});
        showNotification('Task deleted!', 'success');
        
        // Delete animation
        const card = document.querySelector(`[data-task-id="${taskId}"]`);
        if (card) {
            card.style.animation = 'slideOut 0.3s ease forwards';
            setTimeout(() => loadTasks(), 300);
        } else {
            loadTasks();
        }
        
        loadStatus();
    } catch(e) {
        showNotification('Failed to delete task', 'error');
    }
}

// Activity Log
// Current activity filter
let currentActivityFilter = 'all';

function setActivityFilter(filter) {
    currentActivityFilter = filter;
    
    // Update active button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.filter === filter);
    });
    
    // Reload log
    loadActivityLog();
}

async function loadActivityLog() {
    try {
        const data = await apiGet('/api/activity');
        const log = document.getElementById('activity-log');

        if (!data.activities?.length) {
            log.innerHTML = `<div class="empty-log">
                <div style="font-size:2.5rem;margin-bottom:.75rem">📊</div>
                <p style="font-size:1.05rem;font-weight:600;margin-bottom:.4rem">No activity yet</p>
                <p style="color:var(--text-muted);font-size:.88rem">Start monitoring to see results here. 🚀</p>
            </div>`;
            return;
        }

        let items = data.activities;
        if (currentActivityFilter === 'focused')    items = items.filter(a => !a.is_distraction);
        if (currentActivityFilter === 'distracted') items = items.filter(a =>  a.is_distraction);

        if (!items.length) {
            log.innerHTML = `<p class="no-data">No ${currentActivityFilter} activity found. 📝</p>`;
            return;
        }

        log.innerHTML = items.map(a => {
            const conf = a.ai_confidence != null ? Math.round(a.ai_confidence * 100) : null;
            const badge = conf != null
                ? `<span class="conf-badge ${a.is_distraction?'conf-bad':'conf-good'}">${a.is_distraction ? '🚨' : '✅'} ${conf}% sure</span>`
                : '';
            return `
            <div class="activity-item ${a.is_distraction?'distraction':'focused'}">
                <div class="activity-info">
                    <h4>${a.is_distraction ? '🚨' : '✅'} ${esc(a.process_name)} ${badge}</h4>
                    <p>📄 ${esc(a.window_title)}</p>
                    ${a.url ? `<p><small>🔗 ${esc(a.url)}</small></p>` : ''}
                    ${a.ai_reason ? `<p><small>💭 ${esc(a.ai_reason)}</small></p>` : ''}
                </div>
                <div class="activity-time">⏰ ${new Date(a.timestamp).toLocaleTimeString()}</div>
            </div>`;
        }).join('');
    } catch(e) { console.error('loadActivityLog:', e); }
}


// Monitor
async function toggleMonitor() {
    try {
        const st = await apiGet('/api/status');
        await apiPost(st.monitor_running ? '/api/monitor/stop' : '/api/monitor/start', {});
        loadStatus();
    } catch(e) {
        showNotification(e.message || 'Error. Create a task first!', 'error');
    }
}

function testWarning() {
    console.log('[PIE] Testing warning overlay...');
    const testActivity = {
        process: 'chrome.exe',
        process_friendly: 'Google Chrome',
        title: 'Funny Cats Compilation 2024 - YouTube',
        url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        timestamp: new Date().toISOString()
    };
    
    const testAnalysis = {
        is_distraction: true,
        confidence: 0.95,
        reason: "YouTube entertainment video - not related to your coding task",
        action: "block",
        verdict: "This is a distraction! Get back to work."
    };
    
    focusDashboard();
    showWarningOverlay(testActivity, testAnalysis, 999);
    showNotification('Test warning triggered!', 'info');
}

// Settings
async function loadSettings() {
    try {
        const s = await apiGet('/api/settings');
        document.getElementById('check-interval').value = s.check_interval || 5;
        document.getElementById('notifications-enabled').checked =
            s.notification_enabled !== false;
        document.getElementById('auto-close-tab').checked =
            s.auto_close_tab === true;

        const el = document.getElementById('api-status');
        if (s.api_key_set) {
            el.textContent = 'API key is set';
            el.className = 'api-status ok';
        } else {
            el.textContent = 'No API key - AI disabled';
            el.className = 'api-status missing';
        }
        
        // Auto-save handlers
        setupAutoSave();
    } catch(e) { console.error('loadSettings:', e); }
}

function setupAutoSave() {
    // Auto-save when checkbox changes
    const notifCheckbox = document.getElementById('notifications-enabled');
    if (notifCheckbox && !notifCheckbox.dataset.listenerAdded) {
        notifCheckbox.addEventListener('change', async () => {
            const isChecked = notifCheckbox.checked;
            try {
                await apiPost('/api/settings', {
                    notification_enabled: isChecked
                });
                showNotification('Settings saved!', 'success');
            } catch(e) {
                console.error('Error saving notification setting:', e);
                // Revert checkbox if save failed
                notifCheckbox.checked = !isChecked;
            }
        });
        notifCheckbox.dataset.listenerAdded = 'true';
    }
    
    // Auto-save auto-close-tab setting
    const autoCloseCheckbox = document.getElementById('auto-close-tab');
    if (autoCloseCheckbox && !autoCloseCheckbox.dataset.listenerAdded) {
        autoCloseCheckbox.addEventListener('change', async () => {
            const isChecked = autoCloseCheckbox.checked;
            try {
                await apiPost('/api/settings', { auto_close_tab: isChecked });
                showNotification(
                    isChecked ? 'Auto-close enabled.' : 'Auto-close disabled.',
                    'success'
                );
            } catch(e) {
                console.error('Error saving auto-close setting:', e);
                autoCloseCheckbox.checked = !isChecked;
            }
        });
        autoCloseCheckbox.dataset.listenerAdded = 'true';
    }

    // Volume slider - save to localStorage, update label live
    const volumeSlider = document.getElementById('alert-volume');
    if (volumeSlider && !volumeSlider.dataset.listenerAdded) {
        // Restore saved value
        const saved = localStorage.getItem('pie_alert_volume');
        if (saved !== null) {
            volumeSlider.value = saved;
            const lbl = document.getElementById('volume-value');
            if (lbl) lbl.textContent = saved + '%';
        }
        volumeSlider.addEventListener('input', () => {
            const v = volumeSlider.value;
            const lbl = document.getElementById('volume-value');
            if (lbl) lbl.textContent = v + '%';
            localStorage.setItem('pie_alert_volume', v);
        });
        volumeSlider.dataset.listenerAdded = 'true';
    }

    // Auto-save interval with delay
    const intervalInput = document.getElementById('check-interval');
    let intervalTimeout;
    if (intervalInput && !intervalInput.dataset.listenerAdded) {
        intervalInput.addEventListener('input', () => {
            clearTimeout(intervalTimeout);
            intervalTimeout = setTimeout(async () => {
                const interval = parseInt(intervalInput.value);
                try {
                    await apiPost('/api/settings', {
                        check_interval: interval
                    });
                    showNotification('Settings saved!', 'success');
                } catch(e) {
                    console.error('Error saving interval:', e);
                }
            }, 1000); // Save 1 second after last change
        });
        intervalInput.dataset.listenerAdded = 'true';
    }
    
    // Auto-save API key on blur
    const apiKeyInput = document.getElementById('api-key');
    if (apiKeyInput && !apiKeyInput.dataset.listenerAdded) {
        apiKeyInput.addEventListener('blur', async () => {
            const key = apiKeyInput.value.trim();
            if (key) {
                try {
                    await apiPost('/api/settings', {
                        api_key: key
                    });
                    showNotification('API key saved! ', 'success');
                    apiKeyInput.value = ''; // Clear field after saving
                    loadSettings(); // Reload to update API status
                } catch(e) {
                    console.error('Error saving API key:', e);
                }
            }
        });
        apiKeyInput.dataset.listenerAdded = 'true';
    }
}

async function saveSettings() {
    const key      = document.getElementById('api-key').value.trim();
    const interval = parseInt(document.getElementById('check-interval').value);
    const notif    = document.getElementById('notifications-enabled').checked;

    try {
        await apiPost('/api/settings', {
            api_key: key || undefined,
            check_interval: interval,
            notification_enabled: notif
        });
        // Don't reload settings here - it causes checkbox to reset
    } catch(e) {
        console.error('Error saving settings:', e);
    }
}

// Exceptions Management
async function loadExceptionsQuick() {
    try {
        const data = await apiGet('/api/exceptions');
        const warning = document.getElementById('exceptions-warning');
        const list = document.getElementById('exceptions-quick-list');
        
        if (!data.exceptions || data.exceptions.length === 0) {
            warning.style.display = 'none';
            return;
        }
        
        warning.style.display = 'block';
        list.innerHTML = data.exceptions.map(exc => 
            `<div style="padding:0.3rem 0.6rem;background:var(--card-bg);border-radius:4px;margin-bottom:0.3rem;">
                <strong>${esc(exc.app)}</strong>
                ${exc.url ? `: ${esc(exc.url)}` : ' (all websites)'}
            </div>`
        ).join('');
    } catch(e) {
        console.error('loadExceptionsQuick:', e);
    }
}

async function clearExceptionsQuick() {
    if (!confirm('Clear all exceptions? Warnings will show again for all sites/apps.')) {
        return;
    }
    
    try {
        const result = await apiPost('/api/exceptions/clear', {});
        showNotification(`Cleared ${result.count} exceptions! Warnings restored.`, 'success');
        loadExceptionsQuick();
    } catch(e) {
        showNotification('Error clearing exceptions', 'error');
    }
}

async function deleteException(idx) {
    try {
        await apiPost('/api/exceptions/delete', { index: idx });
        showNotification('Exception removed.', 'success');
        loadExceptions();
        loadExceptionsQuick();
    } catch(e) {
        showNotification('Failed to remove exception.', 'error');
    }
}

async function loadExceptions() {
    try {
        const data = await apiGet('/api/exceptions');
        const list = document.getElementById('exceptions-list');

        if (!data.exceptions || data.exceptions.length === 0) {
            list.innerHTML = '<p class="no-data">No exceptions yet. All warnings are active.</p>';
            return;
        }

        list.innerHTML = data.exceptions.map((exc, idx) => `
            <div style="
                background:var(--card-bg);
                padding:0.75rem 1rem;
                border-radius:8px;
                margin-bottom:0.5rem;
                border-left:3px solid var(--warning);
                display:flex;
                align-items:center;
                gap:0.75rem;
            ">
                <div style="flex:1;">
                    <strong>${esc(exc.app)}</strong>
                    ${exc.url
                        ? `<br><small style="color:var(--text-muted);">URL: ${esc(exc.url)}</small>`
                        : `<br><small style="color:var(--text-muted);">All websites</small>`}
                </div>
                <button onclick="deleteException(${idx})" style="
                    background:rgba(239,68,68,0.15);
                    border:1px solid rgba(239,68,68,0.4);
                    color:#ef4444;
                    border-radius:6px;
                    padding:0.3rem 0.7rem;
                    cursor:pointer;
                    font-size:0.85rem;
                    flex-shrink:0;
                ">Remove</button>
            </div>
        `).join('');
    } catch(e) {
        console.error('loadExceptions:', e);
        document.getElementById('exceptions-list').innerHTML =
            '<p class="no-data">Failed to load exceptions</p>';
    }
}

async function clearExceptions() {
    if (!confirm('Clear ALL exceptions? Warnings will show again for all sites/apps.')) {
        return;
    }
    try {
        const result = await apiPost('/api/exceptions/clear', {});
        showNotification('Cleared ' + result.count + ' exceptions!', 'success');
        loadExceptions();
        loadExceptionsQuick();
    } catch(e) {
        showNotification('Error clearing exceptions', 'error');
    }
}

async function addException() {
    const app = document.getElementById('exception-app').value.trim();
    const url = document.getElementById('exception-url').value.trim();
    
    if (!app) {
        showNotification('Please enter an app/process name', 'warning');
        return;
    }
    
    try {
        await apiPost('/api/exceptions/add', {
            app: app,
            url: url || null
        });
        showNotification('Exception added!', 'success');
        document.getElementById('exception-app').value = '';
        document.getElementById('exception-url').value = '';
        loadExceptions();
        loadExceptionsQuick();
    } catch(e) {
        showNotification('Failed to add exception: ' + e.message, 'error');
    }
}

async function resetStats() {
    if (!confirm('Reset all statistics? This will clear Focus Score % and distraction count. Activity log will remain.')) {
        return;
    }
    
    try {
        const result = await apiPost('/api/stats/reset', {});
        showNotification('Statistics reset successfully!', 'success');
        loadStats();
        loadStatus();
    } catch(e) {
        showNotification('Failed to reset statistics: ' + e.message, 'error');
    }
}

async function clearActivityLog() {
    if (!confirm('Clear ALL activity log? This cannot be undone! All recorded activities will be deleted.')) {
        return;
    }
    
    try {
        const result = await apiPost('/api/activity/clear', {});
        showNotification(`Cleared ${result.count} activity entries!`, 'success');
        loadActivityLog();
        loadStats();
    } catch(e) {
        showNotification('Failed to clear activity log: ' + e.message, 'error');
    }
}

// Utils
function esc(text) {
    const d = document.createElement('div');
    d.textContent = String(text || '');
    return d.innerHTML;
}

async function apiGet(path) {
    const r = await fetch(API_BASE + path);
    if (!r.ok) {
        const err = await r.json().catch(() => ({ detail: r.statusText }));
        throw new Error(err.detail || 'Request failed');
    }
    return r.json();
}

async function apiPost(path, body) {
    const r = await fetch(API_BASE + path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
    });
    if (!r.ok) {
        const err = await r.json().catch(() => ({ detail: r.statusText }));
        throw new Error(err.detail || 'Request failed');
    }
    return r.json();
}

function showNotification(msg, type = 'info') {
    const colors = { success: 'var(--success)', error: 'var(--danger)', info: 'var(--primary)' };
    const n = document.createElement('div');
    n.style.cssText = `
        position:fixed;top:20px;right:20px;
        background:${colors[type]};color:white;
        padding:.85rem 1.25rem;border-radius:10px;
        box-shadow:0 10px 25px rgba(0,0,0,.3);
        z-index:10000;font-size:.9rem;font-weight:500;
        animation:slideIn .3s ease;max-width:320px;`;
    n.textContent = msg;
    document.body.appendChild(n);
    setTimeout(() => n.remove(), 4000);
}

// ── Auto-close whitelist ──────────────────────────────────────────────────────

async function loadAutocloseWhitelist() {
    try {
        const data = await apiGet('/api/autoclose-whitelist');
        renderAutocloseWhitelist(data.whitelist || []);
    } catch(e) {
        const el = document.getElementById('autoclose-whitelist-list');
        if (el) el.innerHTML = '<span style="color:var(--danger);font-size:0.82rem;">Failed to load whitelist</span>';
    }
}

function renderAutocloseWhitelist(list) {
    const el = document.getElementById('autoclose-whitelist-list');
    if (!el) return;
    if (!list || list.length === 0) {
        el.innerHTML = '<span style="color:var(--text-muted);font-size:0.82rem;">No apps protected yet. Add browsers or other apps above.</span>';
        return;
    }
    el.innerHTML = list.map(name => `
        <span style="
            display:inline-flex;align-items:center;gap:0.3rem;
            background:var(--bg);border:1px solid var(--border);
            border-radius:20px;padding:0.2rem 0.55rem 0.2rem 0.7rem;
            font-size:0.82rem;color:var(--text);">
            🛡️ ${esc(name)}
            <button onclick="removeFromWhitelist('${esc(name)}')"
                style="background:none;border:none;cursor:pointer;color:var(--danger);font-size:0.9rem;padding:0 0.1rem;line-height:1;"
                title="Remove from whitelist">✕</button>
        </span>`).join('');
}

async function quickAddWhitelist(processName) {
    await _addWhitelist(processName);
}

async function addToWhitelist() {
    const input = document.getElementById('whitelist-add-input');
    const val = (input?.value || '').trim();
    if (!val) { showNotification('Enter a process name first', 'error'); return; }
    await _addWhitelist(val);
    if (input) input.value = '';
}

async function _addWhitelist(processName) {
    try {
        const data = await apiPost('/api/autoclose-whitelist/add', { process_name: processName });
        renderAutocloseWhitelist(data.whitelist);
        showNotification(`🛡️ "${processName}" added to whitelist`, 'success');
    } catch(e) {
        showNotification('Failed to add to whitelist', 'error');
    }
}

async function removeFromWhitelist(processName) {
    try {
        const data = await apiPost('/api/autoclose-whitelist/remove', { process_name: processName });
        renderAutocloseWhitelist(data.whitelist);
        showNotification(`"${processName}" removed from whitelist`, 'info');
    } catch(e) {
        showNotification('Failed to remove from whitelist', 'error');
    }
}

// ─────────────────────────────────────────────────────────────────────────────

// ── Alert Sound (Web Audio API) ───────────────────────────────────────────────

function getAlertVolume() {
    const slider = document.getElementById('alert-volume');
    if (slider) return parseInt(slider.value) / 100;
    const saved = localStorage.getItem('pie_alert_volume');
    return saved !== null ? parseInt(saved) / 100 : 0.7;
}

function playAlertSound(type = 'warn') {
    const vol = getAlertVolume();
    if (vol === 0) return;

    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();

        if (type === 'block') {
            // Three sharp descending beeps for "block"
            [0, 0.18, 0.36].forEach((delay, i) => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.type = 'square';
                osc.frequency.setValueAtTime(880 - i * 180, ctx.currentTime + delay);
                gain.gain.setValueAtTime(vol * 0.4, ctx.currentTime + delay);
                gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + 0.15);
                osc.start(ctx.currentTime + delay);
                osc.stop(ctx.currentTime + delay + 0.15);
            });
        } else {
            // Single soft ping for "warn"
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(660, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.3);
            gain.gain.setValueAtTime(vol * 0.5, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
            osc.start(ctx.currentTime);
            osc.stop(ctx.currentTime + 0.4);
        }
    } catch(e) {
        console.warn('[PIE] Audio playback failed:', e);
    }
}

function previewAlertSound() {
    playAlertSound('block');
}

// ─────────────────────────────────────────────────────────────────────────────

// ── Always-block list ─────────────────────────────────────────────────────────

async function loadAlwaysBlock() {
    try {
        const data = await apiGet('/api/always-block');
        renderAlwaysBlock(data.list || []);
    } catch(e) {
        const el = document.getElementById('always-block-list');
        if (el) el.innerHTML = '<span style="color:var(--danger);font-size:0.82rem;">Failed to load</span>';
    }
}

function renderAlwaysBlock(list) {
    const el = document.getElementById('always-block-list');
    if (!el) return;
    if (!list || list.length === 0) {
        el.innerHTML = '<span style="color:var(--text-muted);font-size:0.82rem;">No apps blocked yet. Add WhatsApp, Telegram or any other app above.</span>';
        return;
    }
    el.innerHTML = list.map(name => `
        <span style="
            display:inline-flex;align-items:center;gap:0.3rem;
            background:rgba(var(--danger-rgb,220,53,69),0.12);
            border:1px solid var(--danger);
            border-radius:20px;padding:0.2rem 0.55rem 0.2rem 0.7rem;
            font-size:0.82rem;color:var(--text);">
            🚫 ${esc(name)}
            <button onclick="removeFromAlwaysBlock('${esc(name)}')"
                style="background:none;border:none;cursor:pointer;color:var(--danger);font-size:0.9rem;padding:0 0.1rem;line-height:1;"
                title="Remove">✕</button>
        </span>`).join('');
}

async function quickAddBlock(processName) {
    await _addAlwaysBlock(processName);
}

async function addToAlwaysBlock() {
    const input = document.getElementById('always-block-input');
    const val = (input?.value || '').trim();
    if (!val) { showNotification('Enter a process name first', 'error'); return; }
    await _addAlwaysBlock(val);
    if (input) input.value = '';
}

async function _addAlwaysBlock(processName) {
    try {
        const data = await apiPost('/api/always-block/add', { process_name: processName });
        renderAlwaysBlock(data.list);
        showNotification(`🚫 "${processName}" will always be blocked`, 'success');
    } catch(e) {
        showNotification('Failed to add', 'error');
    }
}

async function removeFromAlwaysBlock(processName) {
    try {
        const data = await apiPost('/api/always-block/remove', { process_name: processName });
        renderAlwaysBlock(data.list);
        showNotification(`"${processName}" removed from block list`, 'info');
    } catch(e) {
        showNotification('Failed to remove', 'error');
    }
}

// ─────────────────────────────────────────────────────────────────────────────
