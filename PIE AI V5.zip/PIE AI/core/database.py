"""
Database Handler, SQLite storage for tasks, activity logs, and user feedback
Thread-safe; per-method cursors + threading.Lock
"""

import sqlite3
import json
import threading
from datetime import datetime
from typing import Optional, List, Dict
from pathlib import Path


class Database:
    def __init__(self, db_path: str = "pie_ai.db"):
        """
        Initialize database connection.
        Uses a threading.Lock + per-method cursors to avoid
        'Recursive use of cursors' errors from concurrent threads.
        """
        self.db_path = db_path
        self._lock = threading.Lock()
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _cur(self):
        """Return a fresh cursor. Always used inside self._lock."""
        return self.conn.cursor()

    def _create_tables(self):
        """Create database tables if they don't exist"""
        with self._lock:
            cur = self._cur()
            cur.execute('''
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    status TEXT DEFAULT 'active',
                    ai_context TEXT,
                    estimated_duration INTEGER,
                    actual_duration INTEGER
                )
            ''')
            cur.execute('''
                CREATE TABLE IF NOT EXISTS activity_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id INTEGER,
                    timestamp TEXT NOT NULL,
                    process_name TEXT,
                    window_title TEXT,
                    url TEXT,
                    is_distraction INTEGER DEFAULT 0,
                    ai_confidence REAL,
                    ai_reason TEXT,
                    FOREIGN KEY (task_id) REFERENCES tasks(id)
                )
            ''')
            cur.execute('''
                CREATE TABLE IF NOT EXISTS user_feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    activity_log_id INTEGER,
                    timestamp TEXT NOT NULL,
                    user_action TEXT,
                    activity_info TEXT,
                    FOREIGN KEY (activity_log_id) REFERENCES activity_log(id)
                )
            ''')
            cur.execute('''
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            ''')
            self.conn.commit()

    #Task Management

    def create_task(self, title: str, description: str,
                    ai_context: Optional[Dict] = None,
                    estimated_duration: Optional[int] = None) -> int:
        """Create new task. Returns Task ID."""
        now = datetime.now().isoformat()
        with self._lock:
            cur = self._cur()
            cur.execute('''
                INSERT INTO tasks (title, description, created_at, updated_at,
                                   ai_context, estimated_duration)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                title, description, now, now,
                json.dumps(ai_context) if ai_context else None,
                estimated_duration
            ))
            self.conn.commit()
            return cur.lastrowid

    def get_task(self, task_id: int) -> Optional[Dict]:
        """Get task by ID"""
        with self._lock:
            cur = self._cur()
            cur.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))
            row = cur.fetchone()
        if row:
            task = dict(row)
            if task.get('ai_context'):
                task['ai_context'] = json.loads(task['ai_context'])
            return task
        return None

    def get_active_task(self) -> Optional[Dict]:
        """Get currently active task"""
        with self._lock:
            cur = self._cur()
            cur.execute(
                "SELECT * FROM tasks WHERE status = 'active' ORDER BY created_at DESC LIMIT 1"
            )
            row = cur.fetchone()
        if row:
            task = dict(row)
            if task.get('ai_context'):
                task['ai_context'] = json.loads(task['ai_context'])
            return task
        return None

    def update_task_status(self, task_id: int, status: str):
        """Update task status"""
        now = datetime.now().isoformat()
        with self._lock:
            cur = self._cur()
            cur.execute(
                'UPDATE tasks SET status = ?, updated_at = ? WHERE id = ?',
                (status, now, task_id)
            )
            self.conn.commit()

    def delete_task(self, task_id: int):
        """Delete a task and its associated activity logs"""
        with self._lock:
            cur = self._cur()
            # Delete all activity logs related to this task
            cur.execute('DELETE FROM activity_log WHERE task_id = ?', (task_id,))
            # Delete the task itself
            cur.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
            self.conn.commit()

    def get_all_tasks(self, limit: int = 100) -> List[Dict]:
        """Get all tasks"""
        with self._lock:
            cur = self._cur()
            cur.execute(
                'SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?',
                (limit,)
            )
            rows = cur.fetchall()
        
        tasks = []
        for row in rows:
            task = dict(row)
            if task.get('ai_context'):
                try:
                    task['ai_context'] = json.loads(task['ai_context'])
                except:
                    task['ai_context'] = None
            tasks.append(task)
        return tasks

    #Activity Logging

    def log_activity(self, task_id: Optional[int], process_name: str,
                     window_title: str, url: Optional[str] = None,
                     is_distraction: bool = False, ai_confidence: Optional[float] = None,
                     ai_reason: Optional[str] = None) -> int:
        """Log activity. Returns log ID."""
        now = datetime.now().isoformat()
        with self._lock:
            cur = self._cur()
            cur.execute('''
                INSERT INTO activity_log (task_id, timestamp, process_name, window_title,
                                          url, is_distraction, ai_confidence, ai_reason)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                task_id, now, process_name, window_title, url,
                1 if is_distraction else 0, ai_confidence, ai_reason
            ))
            self.conn.commit()
            return cur.lastrowid

    def get_activity_log(self, task_id: Optional[int] = None,
                         limit: int = 100) -> List[Dict]:
        """Get activity logs"""
        with self._lock:
            cur = self._cur()
            if task_id:
                cur.execute(
                    'SELECT * FROM activity_log WHERE task_id = ? ORDER BY timestamp DESC LIMIT ?',
                    (task_id, limit)
                )
            else:
                cur.execute(
                    'SELECT * FROM activity_log ORDER BY timestamp DESC LIMIT ?',
                    (limit,)
                )
            rows = cur.fetchall()
        return [dict(row) for row in rows]

    def get_recent_activity(self, minutes: int = 60, limit: int = 100) -> List[Dict]:
        """Get activity from last N minutes"""
        from datetime import timedelta
        cutoff = (datetime.now() - timedelta(minutes=minutes)).isoformat()
        
        with self._lock:
            cur = self._cur()
            cur.execute(
                'SELECT * FROM activity_log WHERE timestamp >= ? ORDER BY timestamp DESC LIMIT ?',
                (cutoff, limit)
            )
            rows = cur.fetchall()
        return [dict(row) for row in rows]

    def get_distraction_count(self, task_id: Optional[int] = None) -> int:
        """Count distractions"""
        with self._lock:
            cur = self._cur()
            if task_id:
                cur.execute(
                    'SELECT COUNT(*) as count FROM activity_log WHERE task_id = ? AND is_distraction = 1',
                    (task_id,)
                )
            else:
                cur.execute(
                    'SELECT COUNT(*) as count FROM activity_log WHERE is_distraction = 1'
                )
            row = cur.fetchone()
        return row['count'] if row else 0

    #User Feedback

    def log_user_feedback(self, activity_log_id: Optional[int], user_action: str,
                          activity_info: Dict) -> int:
        """Log user feedback. Returns feedback ID."""
        now = datetime.now().isoformat()
        with self._lock:
            cur = self._cur()
            cur.execute('''
                INSERT INTO user_feedback (activity_log_id, timestamp, user_action, activity_info)
                VALUES (?, ?, ?, ?)
            ''', (
                activity_log_id, now, user_action, json.dumps(activity_info)
            ))
            self.conn.commit()
            return cur.lastrowid

    def get_feedback_history(self, limit: int = 100) -> List[Dict]:
        """Get feedback history"""
        with self._lock:
            cur = self._cur()
            cur.execute(
                'SELECT * FROM user_feedback ORDER BY timestamp DESC LIMIT ?',
                (limit,)
            )
            rows = cur.fetchall()
        
        feedback = []
        for row in rows:
            entry = dict(row)
            if entry.get('activity_info'):
                try:
                    entry['activity_info'] = json.loads(entry['activity_info'])
                except:
                    entry['activity_info'] = {}
            feedback.append(entry)
        return feedback

    #Statistics

    def get_productivity_stats(self, task_id: Optional[int] = None) -> Dict:
        """Calculate productivity statistics"""
        with self._lock:
            cur = self._cur()
            if task_id:
                cur.execute('SELECT * FROM activity_log WHERE task_id = ?', (task_id,))
            else:
                cur.execute('SELECT * FROM activity_log')
            activities = cur.fetchall()

        if not activities:
            return {
                'total_activities': 0,
                'distractions': 0,
                'focused_time': 0,
                'distraction_rate': 0.0,
                'focus_score': 0.0
            }

        total = len(activities)
        distractions = sum(1 for a in activities if a['is_distraction'])

        return {
            'total_activities': total,
            'distractions': distractions,
            'focused_activities': total - distractions,
            'distraction_rate': (distractions / total * 100) if total > 0 else 0.0,
            'focus_score': ((total - distractions) / total * 100) if total > 0 else 0.0
        }
    
    def reset_statistics(self):
        """Reset all statistics by clearing is_distraction flag from all activities"""
        with self._lock:
            cur = self._cur()
            # Set all is_distraction to 0 (false) to reset statistics
            cur.execute('UPDATE activity_log SET is_distraction = 0, ai_confidence = NULL, ai_reason = NULL')
            self.conn.commit()
    
    def clear_activity_log(self) -> int:
        """Clear all activity log entries. Returns number of deleted entries."""
        with self._lock:
            cur = self._cur()
            # Count entries before deleting
            cur.execute('SELECT COUNT(*) as count FROM activity_log')
            count = cur.fetchone()['count']
            # Delete all entries
            cur.execute('DELETE FROM activity_log')
            self.conn.commit()
            return count

    #Settings 

    def set_setting(self, key: str, value: str):
        """Save setting"""
        now = datetime.now().isoformat()
        with self._lock:
            cur = self._cur()
            cur.execute(
                'INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
                (key, value, now)
            )
            self.conn.commit()

    def get_setting(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Get setting"""
        with self._lock:
            cur = self._cur()
            cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
            row = cur.fetchone()
        return row['value'] if row else default

    #Utilities

    def get_stats(self) -> Dict:
        """Get database statistics"""
        with self._lock:
            cur = self._cur()
            
            # Total tasks
            cur.execute('SELECT COUNT(*) as count FROM tasks')
            total_tasks = cur.fetchone()['count']
            
            # Active tasks
            cur.execute("SELECT COUNT(*) as count FROM tasks WHERE status = 'active'")
            active_tasks = cur.fetchone()['count']
            
            # Total activity logs
            cur.execute('SELECT COUNT(*) as count FROM activity_log')
            total_logs = cur.fetchone()['count']
            
            # Total distractions
            cur.execute('SELECT COUNT(*) as count FROM activity_log WHERE is_distraction = 1')
            total_distractions = cur.fetchone()['count']
            
            # Total feedback
            cur.execute('SELECT COUNT(*) as count FROM user_feedback')
            total_feedback = cur.fetchone()['count']
        
        return {
            'total_tasks': total_tasks,
            'active_tasks': active_tasks,
            'total_logs': total_logs,
            'total_distractions': total_distractions,
            'total_feedback': total_feedback,
            'db_path': self.db_path
        }

    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()


# Singleton instance
_db_instance = None

def get_database(db_path: str = "pie_ai.db") -> Database:
    """Get singleton database instance"""
    global _db_instance
    if _db_instance is None:
        _db_instance = Database(db_path)
    return _db_instance
