"""
Configuration management
"""

import os
import json
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


class Config:
    def __init__(self):
        self.config_file = Path(__file__).parent.parent / 'config.json'
        self.config_data = self._load_config()

    def _load_config(self):
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Warning: Error reading config.json: {e}")
        return {}

    @property
    def GROQ_API_KEY(self):
        key = self.config_data.get('api_key', '')
        if key and key not in ('YOUR_GROQ_API_KEY_HERE', ''):
            return key
        return os.getenv('GROQ_API_KEY', '')

    @property
    def HOST(self):
        return self.config_data.get('server', {}).get('host', '127.0.0.1')

    @property
    def PORT(self):
        return int(self.config_data.get('server', {}).get('port', 8000))

    @property
    def CHECK_INTERVAL(self):
        return int(self.config_data.get('monitoring', {}).get('check_interval', 5))

    DB_PATH = os.getenv('DB_PATH', 'pie_ai.db')
    BASE_DIR = Path(__file__).parent.parent
    WEB_DIR = BASE_DIR / 'web'
    STATIC_DIR = WEB_DIR / 'static'
    TEMPLATES_DIR = WEB_DIR / 'templates'

    @classmethod
    def validate(cls):
        cfg = cls()
        if not cfg.GROQ_API_KEY:
            return False, "API key not set. Add it to config.json or set GROQ_API_KEY environment variable"
        return True, "Configuration valid"


config = Config()
