"""
Windows Native Toast Notifier for P.I.E AI
Sends real Windows toast notifications (bottom-right corner)
when a distraction is detected.
"""

import threading
from typing import Optional

# Try winotify first (best Windows 10/11 toasts), fallback to win10toast, then plyer
_notifier_backend = None


def _try_import_winotify():
    try:
        from winotify import Notification, audio
        return "winotify"
    except ImportError:
        return None


def _try_import_win10toast():
    try:
        from win10toast import ToastNotifier
        return "win10toast"
    except ImportError:
        return None


def _try_import_plyer():
    try:
        from plyer import notification
        return "plyer"
    except ImportError:
        return None


def _detect_backend():
    for fn in (_try_import_winotify, _try_import_win10toast, _try_import_plyer):
        backend = fn()
        if backend:
            print(f"[PIE Notifier] Using backend: {backend}")
            return backend
    print("[PIE Notifier] WARNING: No notification backend found. "
          "Install winotify: pip install winotify")
    return None


_notifier_backend = _detect_backend()

# winotify singleton toast (one at a time is fine)
_win10toast_instance = None


def _get_win10toast():
    global _win10toast_instance
    if _win10toast_instance is None:
        from win10toast import ToastNotifier
        _win10toast_instance = ToastNotifier()
    return _win10toast_instance


def send_distraction_toast(
    verdict: str,
    reason: str,
    app_name: str = "",
    action: str = "warn",
    duration: int = 6,
) -> bool:
    """
    Send a native Windows toast notification in the bottom-right corner.

    Args:
        verdict:   Short title text shown in the notification (e.g. "YouTube – distraction!")
        reason:    Body text with the AI reason
        app_name:  The offending application name
        action:    "block" or "warn" – used to pick the icon/sound
        duration:  How many seconds the toast stays visible (default 6)

    Returns:
        True if the notification was sent, False otherwise.
    """
    if not _notifier_backend:
        print(f"[PIE Notifier] (no backend) DISTRACTION: {verdict}")
        return False

    title = "⚠️ P.I.E AI – Distraction!" if action == "block" else "⏸ P.I.E AI – Focus check"
    body = verdict
    if reason and reason != verdict:
        body = f"{verdict}\n{reason}"
    if app_name:
        body = f"[{app_name}]\n{body}"

    # Run in a background thread so it never blocks the FastAPI event loop
    thread = threading.Thread(
        target=_fire_toast,
        args=(title, body, duration),
        daemon=True
    )
    thread.start()
    return True


def _fire_toast(title: str, body: str, duration: int):
    """Internal: actually fire the toast (runs in a separate thread)."""
    try:
        if _notifier_backend == "winotify":
            _fire_winotify(title, body)
        elif _notifier_backend == "win10toast":
            _fire_win10toast(title, body, duration)
        elif _notifier_backend == "plyer":
            _fire_plyer(title, body, duration)
    except Exception as e:
        print(f"[PIE Notifier] Toast failed: {e}")


def _fire_winotify(title: str, body: str):
    """winotify backend – best for Windows 10/11 Action Center toasts."""
    from winotify import Notification, audio

    toast = Notification(
        app_id="P.I.E AI",
        title=title,
        msg=body[:200],          # Action Center truncates long messages
        duration="short",        # "short" ≈ 5 s  |  "long" ≈ 25 s
        launch="http://localhost:8000"
    )
    toast.set_audio(audio.Default, loop=False)
    toast.show()


def _fire_win10toast(title: str, body: str, duration: int):
    """win10toast backend."""
    toaster = _get_win10toast()
    toaster.show_toast(
        title,
        body[:200],
        duration=duration,
        threaded=False,          # already in its own thread
    )


def _fire_plyer(title: str, body: str, duration: int):
    """plyer backend – cross-platform fallback."""
    from plyer import notification
    notification.notify(
        title=title,
        message=body[:256],
        app_name="P.I.E AI",
        timeout=duration,
    )
