"""
AI Analyzer, Groq API integration for activity relevance detection.
"""
import requests
import json
import os
import logging
from typing import Dict, Optional
from datetime import datetime
from pathlib import Path


logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s | %(levelname)s | %(funcName)s | %(message)s',
    handlers=[
        logging.FileHandler('ai_analyzer_debug.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class AIAnalyzer:
    def __init__(self, api_key: Optional[str] = None):
        """Initialize AI Analyzer with Groq API."""
        logger.info("=" * 80)
        logger.info("INITIALIZING AI ANALYZER WITH GROQ")
        logger.info("=" * 80)

        # Application whitelist - always allowed, no AI check needed
        self.app_whitelist = [
            'code.exe', 'cursor.exe', 'pycharm', 'pycharm64.exe',
            'idea64.exe', 'webstorm64.exe', 'sublime_text.exe', 'notepad++.exe',
            'atom.exe', 'vim.exe', 'nvim.exe', 'powershell.exe',
            'cmd.exe', 'terminal.exe', 'iterm2', 'explorer.exe',
        ]

        # Domain whitelist - always allowed
        self.domain_whitelist = [
            'google.com', 'localhost', '127.0.0.1',
            'github.com', 'stackoverflow.com',
            'docs.python.org', 'developer.mozilla.org',
        ]

        # User-defined exceptions (added at runtime)
        self.user_exceptions = []

        # Load API key: argument > config.json > environment variable
        if not api_key:
            config_file = Path(__file__).parent.parent / 'config.json'
            if config_file.exists():
                try:
                    with open(config_file, 'r', encoding='utf-8') as f:
                        config_data = json.load(f)
                        api_key = config_data.get('api_key')
                        if api_key in ('YOUR_GROQ_API_KEY_HERE', '', None):
                            api_key = None
                except Exception as e:
                    logger.error(f"Error reading config: {e}")

        if not api_key:
            api_key = os.getenv('GROQ_API_KEY')
            if api_key:
                logger.debug("Found API key in environment variable")

        self.api_key = api_key
        self.ai_available = bool(api_key)

        if not self.ai_available:
            logger.warning("NO API KEY FOUND - RUNNING IN FALLBACK MODE")
            print("\n" + "=" * 50)
            print("WARNING: GROQ API KEY NOT FOUND - RUNNING IN FALLBACK MODE")
            print("Add your free key to config.json -> 'api_key': 'gsk_...'")
            print("Get a free key at: https://console.groq.com/keys")
            print("=" * 50 + "\n")
        else:
            self.available_models = [
                "llama-3.3-70b-versatile",
                "llama-3.1-8b-instant",
                "mixtral-8x7b-32768",
                "gemma2-9b-it",
            ]
            self.model = "llama-3.3-70b-versatile"
            self.api_url = "https://api.groq.com/openai/v1/chat/completions"
            logger.info("Groq AI connected successfully")
            logger.info(f"Model: {self.model}")
            logger.info(f"Available models: {', '.join(self.available_models)}")
            logger.info(f"API endpoint: {self.api_url}")
            print(f"Groq AI connected (model: {self.model})")
            print("Rate limits: 30 req/min, 14,400 req/day")

        self.task_context_cache = None
        self.user_feedback_history = []
        self.request_count = 0

    def set_model(self, model_name: str):
        """Switch the active Groq model."""
        if hasattr(self, 'available_models') and model_name in self.available_models:
            self.model = model_name
            logger.info(f"Model changed to: {model_name}")
            print(f"Model changed to: {model_name}")
        else:
            logger.warning(f"Model '{model_name}' not in available models list")

    def _query_model(self, prompt: str, retry_with_other_models: bool = True) -> str:
        """Send a prompt to Groq and return the raw text response."""
        if not self.ai_available:
            return ""

        self.request_count += 1
        logger.info(f"REQUEST #{self.request_count} TO GROQ API")

        models_to_try = [self.model]
        if retry_with_other_models and hasattr(self, 'available_models'):
            models_to_try.extend([m for m in self.available_models if m != self.model])

        for attempt, model in enumerate(models_to_try, 1):
            logger.info(f"Trying model: {model} (attempt {attempt}/{len(models_to_try)})")
            payload = {
                "model": model,
                "messages": [
                    {"role": "system", "content": "You are a productivity AI assistant. Always respond with valid JSON only."},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.1,
                "max_tokens": 500,
                "response_format": {"type": "json_object"}
            }

            try:
                start_time = datetime.now()
                response = requests.post(
                    self.api_url,
                    headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
                    json=payload,
                    timeout=15
                )
                elapsed = (datetime.now() - start_time).total_seconds()
                logger.info(f"Response received in {elapsed:.2f}s")

                if response.status_code == 200:
                    result = response.json()
                    choices = result.get("choices", [])
                    if choices:
                        text = choices[0]["message"]["content"]
                        logger.info(f"SUCCESS - Response length: {len(text)} chars")
                        if model != self.model:
                            logger.info(f"Automatically switched to working model: {model}")
                            print(f"Automatically switched to model: {model}")
                            self.model = model
                        return text.strip()
                    else:
                        logger.error("No choices in response")
                        continue
                else:
                    error_data = {}
                    try:
                        error_data = response.json()
                    except Exception:
                        pass
                    error_msg = error_data.get("error", {}).get("message", response.text[:100])
                    error_code = error_data.get("error", {}).get("code", "")
                    logger.error(f"GROQ API ERROR {response.status_code}: {error_msg}")

                    if "decommissioned" in error_msg.lower() or error_code == "model_decommissioned":
                        print(f"Model {model} is decommissioned, trying next...")
                        continue
                    if response.status_code in (401, 403):
                        logger.critical("INVALID API KEY - switching to fallback mode")
                        print("Invalid API key - switching to fallback mode")
                        self.ai_available = False
                        return ""
                    continue

            except requests.exceptions.Timeout:
                logger.error("Request timeout after 15 seconds")
                continue
            except requests.exceptions.ConnectionError as e:
                logger.error(f"Connection error: {e}")
                continue
            except Exception as e:
                logger.exception(f"Unexpected exception: {e}")
                continue

        logger.error("All models failed")
        print("All models failed - switching to fallback mode")
        return ""

    def _parse_json_from_response(self, text: str) -> Optional[dict]:
        """Extract and parse a JSON object from the model response text."""
        if not text:
            return None

        text = text.strip()
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
        text = text.strip().strip("`")

        try:
            result = json.loads(text)
            logger.info(f"Successfully parsed JSON: {list(result.keys())}")
            return result
        except json.JSONDecodeError:
            pass

        start = text.find('{')
        end = text.rfind('}') + 1
        if start != -1 and end > start:
            try:
                result = json.loads(text[start:end])
                logger.info(f"Extracted JSON successfully: {list(result.keys())}")
                return result
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse extracted JSON: {e}")

        logger.error("Could not find valid JSON in response")
        return None

    def analyze_task_description(self, task_description: str) -> Dict:
        """Analyze a task description with AI to build context for activity checks."""
        logger.info("=" * 80)
        logger.info(f"ANALYZING TASK: {task_description}")
        logger.info("=" * 80)
        print(f"Analyzing task: {task_description[:80]}...")

        if self.ai_available:
            prompt = f"""Analyze this work task and return a JSON object.

Task: {task_description}

Return a JSON object with these fields:
- goal: one sentence summary of what the person is building/doing
- keywords: array of 5-8 relevant keywords
- project_type: one of [coding/design/writing/research/other]
- acceptable_domains: array of 5-10 relevant domains/sites for this task
- focus_level: number from 1-10 (how much focus this task requires)

Example:
{{
    "goal": "Building a Python web scraper for real estate data",
    "keywords": ["python", "scraping", "beautifulsoup", "requests", "real estate"],
    "project_type": "coding",
    "acceptable_domains": ["github.com", "stackoverflow.com", "docs.python.org", "realpython.com"],
    "focus_level": 8
}}
"""
            response_text = self._query_model(prompt)
            analysis = self._parse_json_from_response(response_text)

            if analysis:
                logger.info("Task analyzed successfully")
                print(f"Task analyzed: {analysis.get('goal', '')[:60]}")
            else:
                logger.warning("AI analysis failed, using fallback")
                print("AI analysis failed, using fallback")
                analysis = self._create_fallback_analysis(task_description)
        else:
            analysis = self._create_fallback_analysis(task_description)

        for key, default in [
            ('goal', task_description[:100]),
            ('keywords', []),
            ('project_type', 'general'),
            ('acceptable_domains', ['google.com', 'github.com', 'stackoverflow.com']),
            ('focus_level', 7)
        ]:
            if key not in analysis:
                analysis[key] = default

        self.task_context_cache = analysis
        return analysis

    def _create_fallback_analysis(self, task_description: str) -> Dict:
        """Build a basic task context without AI."""
        words = task_description.lower().split()
        keywords = [w.strip('.,!?;:') for w in words if len(w) > 4][:8]

        project_type = "general"
        desc_lower = task_description.lower()
        if any(w in desc_lower for w in ['code', 'python', 'programming', 'app', 'website', 'script']):
            project_type = "coding"
        elif any(w in desc_lower for w in ['write', 'article', 'essay', 'blog', 'content']):
            project_type = "writing"
        elif any(w in desc_lower for w in ['design', 'ui', 'ux', 'logo', 'figma']):
            project_type = "design"
        elif any(w in desc_lower for w in ['research', 'study', 'analyze', 'investigate']):
            project_type = "research"

        acceptable_domains = ["google.com", "github.com", "stackoverflow.com"]
        if project_type == "coding":
            acceptable_domains.extend(["python.org", "docs.python.org", "pypi.org", "realpython.com"])
        elif project_type == "design":
            acceptable_domains.extend(["figma.com", "dribbble.com", "behance.net", "adobe.com"])
        elif project_type == "writing":
            acceptable_domains.extend(["grammarly.com", "hemingwayapp.com", "docs.google.com"])

        return {
            "goal": task_description[:120],
            "keywords": keywords,
            "project_type": project_type,
            "acceptable_domains": acceptable_domains,
            "focus_level": 7
        }

    def check_activity_relevance(
        self,
        current_activity: str,
        window_title: str,
        url: Optional[str] = None
    ) -> Dict:
        """
        Determine whether the current activity is a distraction from the active task.

        Priority order:
          1. App whitelist  -> auto allow
          2. Domain whitelist -> auto allow
          3. User exceptions -> auto allow
          4. AI analysis
          5. Keyword fallback (if AI unavailable)
        """
        logger.info("-" * 80)
        logger.info("CHECKING ACTIVITY RELEVANCE")
        logger.info(f"  App: {current_activity}")
        logger.info(f"  Title: {window_title}")
        logger.info(f"  URL: {url or 'N/A'}")
        logger.info("-" * 80)

        app_lower = current_activity.lower()

        # 1. App whitelist
        for whitelist_app in self.app_whitelist:
            if whitelist_app.lower() in app_lower:
                logger.info(f"App '{current_activity}' in whitelist - auto allowed")
                return {"is_distraction": False, "confidence": 1.0,
                        "reason": f"'{current_activity}' is a whitelisted work tool",
                        "action": "allow", "verdict": f"{current_activity} - work tool"}

        # 2. Domain whitelist — but skip if title hints at off-task content
        if url:
            url_lower = url.lower()
            # These title keywords mean the user is browsing something off-task
            offtrack_hints = [
                'wikipedia', 'wiki', 'youtube', 'reddit', 'twitter', 'facebook',
                'instagram', 'tiktok', 'netflix', 'twitch', 'vk.com',
                'funny', 'meme', 'cats', 'cat', 'котик', 'кот',
            ]
            title_lower = window_title.lower()
            title_offtrack = any(h in title_lower for h in offtrack_hints)

            for whitelist_domain in self.domain_whitelist:
                if whitelist_domain in url_lower:
                    if 'google.com' in url_lower:
                        if title_offtrack:
                            # Title hints at off-task browsing — let AI decide
                            logger.info("Google URL but off-task title detected — sending to AI")
                            break
                        logger.info("Google homepage/search - auto allowed")
                        return {"is_distraction": False, "confidence": 0.9,
                                "reason": "Google search is acceptable",
                                "action": "allow", "verdict": "Google search allowed"}
                    else:
                        logger.info(f"Domain '{whitelist_domain}' in whitelist - auto allowed")
                        return {"is_distraction": False, "confidence": 0.95,
                                "reason": f"'{whitelist_domain}' is whitelisted",
                                "action": "allow", "verdict": f"{whitelist_domain} - allowed"}

        # 3. User exceptions
        for exception in self.user_exceptions:
            exception_app = exception.get('app', '').lower()
            exception_url = exception.get('url', '').lower()
            if exception_app in app_lower:
                if exception_url:
                    if url and exception_url in url.lower():
                        return {"is_distraction": False, "confidence": 1.0,
                                "reason": f"User exception: {exception_app} @ {exception_url}",
                                "action": "allow", "verdict": "User exception - allowed"}
                else:
                    return {"is_distraction": False, "confidence": 1.0,
                            "reason": f"User exception: {exception_app}",
                            "action": "allow", "verdict": "User exception - allowed"}

        # 4. AI analysis
        if not self.ai_available or not self.task_context_cache:
            return self._check_activity_fallback(current_activity, window_title, url)

        task_context = self.task_context_cache
        prompt = f"""You are a productivity assistant. Analyze if this activity is relevant to the work task.

TASK CONTEXT:
- Goal: {task_context.get('goal', '')}
- Keywords: {', '.join(task_context.get('keywords', []))}
- Project type: {task_context.get('project_type', '')}
- Acceptable domains: {', '.join(task_context.get('acceptable_domains', []))}

CURRENT ACTIVITY:
- Application: {current_activity}
- Window title: {window_title}
- URL: {url or 'N/A'}

INSTRUCTIONS:
1. If the activity is CLEARLY entertainment or distraction (YouTube videos, social media, games, memes, etc.) - mark as distraction
2. If the activity is DIRECTLY related to the task - mark as productive
3. If unclear but could be work-related - give the benefit of the doubt (mark as productive)
4. YouTube/Reddit CAN be productive (tutorials, technical discussions) - judge by title context

Return JSON:
{{
    "is_distraction": true/false,
    "confidence": 0.0-1.0,
    "reason": "brief explanation",
    "action": "block" or "warn" or "allow",
    "verdict": "brief user-facing message"
}}

Action rules: "block" >0.75 confidence, "warn" 0.5-0.75, "allow" otherwise
"""

        response_text = self._query_model(prompt)
        ai_verdict = self._parse_json_from_response(response_text)

        if ai_verdict:
            logger.info(f"AI VERDICT: {json.dumps(ai_verdict, indent=2)}")
            for key, default in [
                ('is_distraction', False), ('confidence', 0.5),
                ('reason', 'AI analysis'), ('action', 'allow'), ('verdict', 'Activity analyzed')
            ]:
                if key not in ai_verdict:
                    ai_verdict[key] = default

            verdict_label = "DISTRACTION" if ai_verdict.get('is_distraction') else "ALLOWED"
            logger.info(f"{verdict_label}: {ai_verdict.get('verdict', '')}")
            print(f"AI verdict: {verdict_label} ({ai_verdict.get('confidence', 0):.0%}) - {ai_verdict.get('verdict', '')}")
            return ai_verdict

        # 5. Fallback
        logger.warning("AI response failed - using fallback")
        print("AI response failed - using fallback logic")
        return self._check_activity_fallback(current_activity, window_title, url)

    def _check_activity_fallback(
        self,
        current_activity: str,
        window_title: str,
        url: Optional[str] = None
    ) -> Dict:
        """Keyword-based fallback when AI is unavailable."""
        logger.info("Using fallback activity check...")

        strong_distraction_keywords = [
            'youtube.com/watch', 'youtu.be/', 'instagram.com', 'facebook.com',
            'twitter.com', 'x.com', 'tiktok.com', 'netflix.com', 'twitch.tv',
            'reddit.com/r/funny', 'reddit.com/r/memes', '9gag', 'imgur.com', 'vk.com',
            'gaming', 'funny', 'meme', 'compilation', 'reaction', 'shorts', 'fail',
        ]
        medium_distraction_keywords = ['news', 'sport', 'sports', 'reddit.com', 'youtube.com']
        productive_keywords = [
            'stackoverflow', 'github', 'docs.', 'documentation', 'tutorial',
            'programming', 'coding', 'development', 'python', 'javascript',
            'learn', 'course', 'how to', 'api', 'library', 'framework',
        ]

        combined = f"{window_title} {url or ''}".lower()

        for keyword in strong_distraction_keywords:
            if keyword in combined:
                return {"is_distraction": True, "confidence": 0.85,
                        "reason": f"Detected '{keyword}' - likely entertainment",
                        "action": "block", "verdict": "This looks like a distraction."}

        for keyword in medium_distraction_keywords:
            if keyword in combined:
                return {"is_distraction": True, "confidence": 0.65,
                        "reason": f"Detected '{keyword}' - possibly distracting",
                        "action": "warn", "verdict": "Is this related to work?"}

        for keyword in productive_keywords:
            if keyword in combined:
                return {"is_distraction": False, "confidence": 0.75,
                        "reason": f"Detected '{keyword}' - appears work-related",
                        "action": "allow", "verdict": "Productive content"}

        return {"is_distraction": False, "confidence": 0.3,
                "reason": "No clear indicators - allowing to be safe",
                "action": "allow", "verdict": "Activity allowed (uncertain)"}

    def add_user_exception(self, app: str, url: Optional[str] = None):
        """
        Add a user exception so a specific app/URL is never flagged.
        For browsers, a URL is required.
        """
        browser_apps = ['chrome.exe', 'firefox.exe', 'msedge.exe', 'opera.exe', 'brave.exe', 'safari']
        if any(b in app.lower() for b in browser_apps) and not url:
            print("Cannot allow entire browser - a specific URL is required")
            return

        exception = {"app": app.lower()}
        if url:
            if 'youtube.com' in url.lower() and 'watch?v=' in url:
                video_id = url.split('watch?v=')[1].split('&')[0]
                exception["url"] = f"youtube.com/watch?v={video_id}"
            else:
                exception["url"] = url.lower()

        for existing in self.user_exceptions:
            if existing.get('app') == exception['app'] and existing.get('url') == exception.get('url'):
                return

        self.user_exceptions.append(exception)
        logger.info(f"User exception added: {exception}")
        print(f"Exception added: {app}" + (f" @ {exception.get('url')}" if url else " (entire app)"))

    def clear_user_exceptions(self) -> int:
        """Remove all user exceptions. Returns the count removed."""
        count = len(self.user_exceptions)
        self.user_exceptions = []
        print(f"Exceptions removed: {count}")
        return count

    def get_user_exceptions(self) -> list:
        """Return a copy of the current user exceptions list."""
        return self.user_exceptions.copy()

    def learn_from_feedback(self, activity_info: Dict, user_choice: str):
        """Log user feedback for context."""
        feedback_entry = {
            "timestamp": datetime.now().isoformat(),
            "activity": activity_info,
            "user_choice": user_choice
        }
        self.user_feedback_history.append(feedback_entry)
        logger.info(f"Feedback logged: {json.dumps(feedback_entry, indent=2)}")
        print(f"Feedback logged: '{user_choice}' for "
              f"{activity_info.get('url', activity_info.get('title', 'unknown'))}")

    def get_stats(self) -> Dict:
        """Return current usage statistics."""
        stats = {
            "api_requests": self.request_count,
            "ai_available": self.ai_available,
            "feedback_count": len(self.user_feedback_history),
            "task_active": bool(self.task_context_cache),
            "model": self.model if self.ai_available else "fallback"
        }
        return stats


if __name__ == "__main__":
    print("Testing AIAnalyzer with Groq...")
    analyzer = AIAnalyzer()

    task = "Write a Python script to scrape weather data from websites"
    analysis = analyzer.analyze_task_description(task)
    print(f"\nTask Analysis:\n{json.dumps(analysis, indent=2)}")

    result = analyzer.check_activity_relevance(
        "Google Chrome",
        "Beautiful Soup documentation - Python",
        "https://www.crummy.com/software/BeautifulSoup/bs4/doc/"
    )
    print(f"\nActivity Check:\n{json.dumps(result, indent=2)}")
    print(f"\nStats:\n{json.dumps(analyzer.get_stats(), indent=2)}")
