"""
Productivity Monitor, Main orchestration class
activity monitoring, AI analysis, and database tracking
"""

from typing import Optional, Dict, Callable
from .monitor import ActivityMonitor
from .ai_analyzer import AIAnalyzer
from .database import Database


class ProductivityMonitor:
    def __init__(self, api_key: Optional[str] = None, check_interval: int = 5):
        """
        Initialize Productivity Monitor
        
        Args:
            api_key: Optional Gemini API key
            check_interval: Seconds between activity checks
        """
        # Initialize database
        self.db = Database()
        
        # Initialize activity monitor
        self.activity_monitor = ActivityMonitor(
            callback=self._on_activity_change,
            check_interval=check_interval
        )
        
        # Initialize AI analyzer (may fail gracefully if no API key)
        try:
            self.ai_analyzer = AIAnalyzer(api_key=api_key)
        except Exception as e:
            print(f"  Failed to initialize AI: {e}")
            print("   Running in fallback mode")
            self.ai_analyzer = None
        
        # Current task
        self.current_task_id = None
        self.current_task_context = None
        
        # Callbacks
        self.on_distraction_detected: Optional[Callable] = None
        
        # Stats
        self.total_checks = 0
        self.distractions_detected = 0
        self.distractions_blocked = 0
    
    def _on_activity_change(self, activity: Dict):
        """
        Handle activity change from monitor
        
        Args:
            activity: Activity information dictionary
        """
        self.total_checks += 1
        
        # If no task is active, just log
        if not self.current_task_id:
            return
        
        # Check with AI if this is a distraction
        if self.ai_analyzer and self.ai_analyzer.task_context_cache:
            result = self.ai_analyzer.check_activity_relevance(
                current_activity=activity.get('process', ''),
                window_title=activity.get('title', ''),
                url=activity.get('url')
            )
            
            # Log to database
            activity_log_id = self.db.log_activity(
                task_id=self.current_task_id,
                activity_info=activity,
                is_distraction=result.get('is_distraction', False),
                ai_confidence=result.get('confidence', 0.0),
                ai_reason=result.get('reason', '')
            )
            
            # Handle distractions
            if result.get('is_distraction'):
                self.distractions_detected += 1
                
                if result.get('action') == 'block':
                    self.distractions_blocked += 1
                
                # Trigger callback if set
                if self.on_distraction_detected:
                    self.on_distraction_detected(activity, result, activity_log_id)
    
    def start_task(self, title: str, description: str, estimated_duration: Optional[int] = None) -> int:
        """
        Start a new task
        
        Args:
            title: Task title
            description: Detailed task description
            estimated_duration: Estimated duration in minutes
            
        Returns:
            Task ID
        """
        # Analyze task with AI
        if self.ai_analyzer:
            ai_context = self.ai_analyzer.analyze_task_description(description)
        else:
            ai_context = None
        
        # Create task in database
        task_id = self.db.create_task(
            title=title,
            description=description,
            ai_context=ai_context,
            estimated_duration=estimated_duration
        )
        
        self.current_task_id = task_id
        self.current_task_context = ai_context
        
        return task_id
    
    def stop_task(self):
        """Stop current task"""
        if self.current_task_id:
            self.db.update_task_status(self.current_task_id, 'completed')
            self.current_task_id = None
            self.current_task_context = None
            
            if self.ai_analyzer:
                self.ai_analyzer.task_context_cache = None
    
    def start_monitoring(self):
        """Start activity monitoring"""
        self.activity_monitor.start()
    
    def stop_monitoring(self):
        """Stop activity monitoring"""
        self.activity_monitor.stop()
    
    def get_current_activity(self) -> Optional[Dict]:
        """Get current activity"""
        return self.activity_monitor.get_current_activity()
    
    def get_stats(self) -> Dict:
        """
        Get monitoring statistics
        
        Returns:
            Statistics dictionary
        """
        db_stats = self.db.get_productivity_stats(self.current_task_id)
        
        return {
            **db_stats,
            'total_checks': self.total_checks,
            'distractions_detected': self.distractions_detected,
            'distractions_blocked': self.distractions_blocked,
            'monitor_running': self.activity_monitor.running,
            'task_active': self.current_task_id is not None,
            'ai_enabled': self.ai_analyzer is not None and self.ai_analyzer.ai_available
        }
    
    def log_user_feedback(self, activity_log_id: int, action: str, activity_info: Dict):
        """
        Log user feedback
        
        Args:
            activity_log_id: Activity log ID
            action: User action ('continue' or 'close')
            activity_info: Activity information
        """
        self.db.log_user_feedback(activity_log_id, action, activity_info)
        
        if self.ai_analyzer:
            self.ai_analyzer.learn_from_feedback(activity_info, action)
    
    def close(self):
        """Cleanup resources"""
        self.stop_monitoring()
        self.db.close()
