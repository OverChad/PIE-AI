"""
Activity Monitor, Tracks users active windows, applications, and browser activity
Windows specific implementation using win32
"""

import time
import psutil
import threading
from datetime import datetime
from typing import Optional, Dict, Callable
import json

# Windows specific imports
try:
    import win32gui
    import win32process
    import win32api
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False
    print("Warning: win32 modules not available. Install pywin32 for full functionality.")


class ActivityMonitor:
    def __init__(self, callback: Optional[Callable] = None, check_interval: int = 3):
        """
        Initialize Activity Monitor
        
        Args:
            callback: Function to call when activity changes
            check_interval: Seconds between activity checks
        """
        self.callback = callback
        self.check_interval = check_interval
        self.running = False
        self.current_activity = None
        self.monitor_thread = None
        
        # Browser process names to track
        self.browsers = {
            'chrome.exe': 'Google Chrome',
            'firefox.exe': 'Mozilla Firefox',
            'msedge.exe': 'Microsoft Edge',
            'opera.exe': 'Opera',
            'brave.exe': 'Brave Browser',
            'safari.exe': 'Safari'
        }
        
        # Windows system apps to ignore
        self.windows_system_apps = {
            'searchapp.exe',           # Windows Search / Поиск Windows
            'searchui.exe',            # Windows Search UI
            'searchhost.exe',          # Windows Search Host
            'startmenuexperiencehost.exe',  # Start Menu
            'shellexperiencehost.exe', # Shell Experience (Calendar, etc)
            'applicationframehost.exe', # UWP app host
            'calculator.exe',          # Калькулятор
            'calc.exe',                # Калькулятор (старая версия)
            'snippingtool.exe',        # Ножницы
            'snip.exe',                # Snip & Sketch
            'screenclippinghost.exe',  # Screen Clipping
            'mspaint.exe',             # Paint
            'notepad.exe',             # Блокнот
            'explorer.exe',            # File Explorer
            'taskmgr.exe',             # Task Manager
            'mmc.exe',                 # Management Console
            'control.exe',             # Control Panel
            'systemsettings.exe',      # Windows Settings
            'winver.exe',              # Windows Version
            'msconfig.exe',            # System Configuration
            'regedit.exe',             # Registry Editor
            'cmd.exe',                 # Command Prompt
            'powershell.exe',          # PowerShell
            'windowsterminal.exe',     # Windows Terminal
            'conhost.exe',             # Console Host
            'dllhost.exe',             # COM Surrogate
            'dwm.exe',                 # Desktop Window Manager
            'sihost.exe',              # Shell Infrastructure Host
            'runtimebroker.exe',       # Runtime Broker
            'backgroundtaskhost.exe',  # Background Tasks
            'yourphone.exe',           # Your Phone app
            'lockapp.exe',             # Lock Screen
            'oobe.exe',                # Out of Box Experience
        }
        
    def get_active_window_info(self) -> Dict:
        """
        Get information about currently active window
        
        Returns:
            Dictionary with window title, process name, and URL (if browser)
        """
        if not HAS_WIN32:
            return {
                'title': 'Unknown (win32 not available)',
                'process': 'unknown',
                'url': None,
                'timestamp': datetime.now().isoformat()
            }
        
        try:
            # Get active window handle
            hwnd = win32gui.GetForegroundWindow()
            
            # Get window title
            window_title = win32gui.GetWindowText(hwnd)
            
            # Get process ID and name
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            
            try:
                process = psutil.Process(pid)
                process_name = process.name()
            except:
                process_name = "unknown"
            
            # Try to extract URL from browser window title
            url = None
            if process_name.lower() in self.browsers:
                url = self._extract_url_from_title(window_title, process_name)
            
            return {
                'title': window_title,
                'process': process_name,
                'process_friendly': self.browsers.get(process_name.lower(), process_name),
                'url': url,
                'timestamp': datetime.now().isoformat(),
                'is_browser': process_name.lower() in self.browsers
            }
            
        except Exception as e:
            return {
                'title': f'Error: {str(e)}',
                'process': 'error',
                'url': None,
                'timestamp': datetime.now().isoformat()
            }
    
    def _extract_url_from_title(self, title: str, process: str) -> Optional[str]:
        """
        Attempt to extract URL/domain from browser window title.
        Enhanced version with better pattern matching.
        """
        import re
        title_lower = title.lower()

        # Map of keywords in title -> domain (expanded list)
        domain_map = [
            ('wikipedia', 'wikipedia.org'),
            ('youtube', 'youtube.com'),
            ('github', 'github.com'),
            ('stack overflow', 'stackoverflow.com'),
            ('stackoverflow', 'stackoverflow.com'),
            ('reddit', 'reddit.com'),
            ('twitter', 'twitter.com'),
            ('x.com', 'x.com'),
            ('instagram', 'instagram.com'),
            ('facebook', 'facebook.com'),
            ('linkedin', 'linkedin.com'),
            ('gmail', 'gmail.com'),
            ('google docs', 'docs.google.com'),
            ('google sheets', 'sheets.google.com'),
            ('google drive', 'drive.google.com'),
            ('google', 'google.com'),
            ('netflix', 'netflix.com'),
            ('twitch', 'twitch.tv'),
            ('tiktok', 'tiktok.com'),
            ('discord', 'discord.com'),
            ('slack', 'slack.com'),
            ('notion', 'notion.so'),
            ('figma', 'figma.com'),
            ('vercel', 'vercel.com'),
            ('heroku', 'heroku.com'),
            ('aws', 'aws.amazon.com'),
            ('azure', 'azure.microsoft.com'),
            ('huggingface', 'huggingface.co'),
            ('colab', 'colab.research.google.com'),
            ('kaggle', 'kaggle.com'),
            ('medium', 'medium.com'),
            ('dev.to', 'dev.to'),
            ('mozilla', 'developer.mozilla.org'),
            ('mdn', 'developer.mozilla.org'),
            ('docs.python', 'docs.python.org'),
            ('pypi', 'pypi.org'),
            ('npm', 'npmjs.com'),
            ('chatgpt', 'chatgpt.com'),
            ('claude', 'claude.ai'),
            ('purina', 'purina.com'),
            ('amazon', 'amazon.com'),
            ('ebay', 'ebay.com'),
            ('aliexpress', 'aliexpress.com'),
            ('booking', 'booking.com'),
            ('airbnb', 'airbnb.com'),
            ('spotify', 'spotify.com'),
            ('soundcloud', 'soundcloud.com'),
        ]

        # Check by keywords first
        for keyword, domain in domain_map:
            if keyword in title_lower:
                return f"https://{domain}"

        # Try to extract domain from title using pattern matching
        # Many sites show "Title - domain.com" or "Title | domain.com"
        url_pattern = r'[-–|•]\s*([a-zA-Z0-9-]+\.[a-zA-Z]{2,})'
        match = re.search(url_pattern, title)
        if match:
            domain = match.group(1).strip()
            # Make sure it looks like a real domain
            if len(domain) > 3 and '.' in domain:
                return f"https://{domain}"
        
        # Look for domain-like patterns anywhere in title
        # e.g., "example.com", "site.io", etc.
        if '.' in title:
            words = title.split()
            for word in words:
                # Clean the word
                cleaned = word.strip('(),[]|"\'`').lower()
                # Check if it looks like a domain
                if '.' in cleaned and len(cleaned.split('.')) >= 2:
                    # Check for common TLDs
                    common_tlds = [
                        '.com', '.org', '.net', '.io', '.ai', '.co', 
                        '.ru', '.uk', '.de', '.fr', '.jp', '.cn',
                        '.info', '.biz', '.me', '.tv', '.app',
                        '.dev', '.tech', '.online', '.site', '.website'
                    ]
                    if any(cleaned.endswith(tld) for tld in common_tlds):
                        # Validate it's not too long or weird
                        if len(cleaned) < 100 and cleaned.count('.') <= 4:
                            return f"https://{cleaned}"
        
        # Last resort: check if title contains "www."
        www_pattern = r'www\.([a-zA-Z0-9-]+\.[a-zA-Z]{2,})'
        match = re.search(www_pattern, title_lower)
        if match:
            return f"https://www.{match.group(1)}"

        # If we can't extract URL, return None
        # The window title will still be shown in the UI
        return None
    
    def get_running_applications(self) -> list:
        """
        Get list of all running applications
        
        Returns:
            List of process names
        """
        try:
            processes = []
            for proc in psutil.process_iter(['name', 'pid']):
                try:
                    processes.append({
                        'name': proc.info['name'],
                        'pid': proc.info['pid']
                    })
                except:
                    continue
            return processes
        except:
            return []
    
    def _monitor_loop(self):
        """
        Main monitoring loop (runs in separate thread)
        """
        last_activity = None
        
        while self.running:
            try:
                # Get current activity
                activity = self.get_active_window_info()
                
                # Skip Windows system apps
                if activity['process'].lower() in self.windows_system_apps:
                    time.sleep(self.check_interval)
                    continue
                
                # Check if activity changed
                activity_key = f"{activity['process']}|{activity['title']}"
                
                if activity_key != last_activity:
                    last_activity = activity_key
                    self.current_activity = activity
                    
                    # Trigger callback if set
                    if self.callback:
                        self.callback(activity)
                
                # Wait before next check
                time.sleep(self.check_interval)
                
            except Exception as e:
                print(f"Monitor error: {e}")
                time.sleep(self.check_interval)
    
    def start(self):
        """
        Start monitoring in background thread
        """
        if self.running:
            print("Monitor already running")
            return
        
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        print("Activity monitor started")
    
    def stop(self):
        """
        Stop monitoring
        """
        self.running = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        print("Activity monitor stopped")
    
    def get_current_activity(self) -> Optional[Dict]:
        """
        Get the most recent activity
        
        Returns:
            Current activity dictionary or None
        """
        return self.current_activity


# Example usage and testing
if __name__ == "__main__":
    def on_activity_change(activity):
        """Callback function for activity changes"""
        print(f"\n{'='*60}")
        print(f"Time: {activity['timestamp']}")
        print(f"Application: {activity['process_friendly']}")
        print(f"Window: {activity['title']}")
        if activity.get('url'):
            print(f"URL: {activity['url']}")
        print('='*60)
    
    # Create and start monitor
    monitor = ActivityMonitor(callback=on_activity_change, check_interval=2)
    
    print("Starting activity monitor...")
    print("Switch between different applications to see tracking in action")
    print("Press Ctrl+C to stop")
    
    monitor.start()
    
    try:
        # Keep running
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping monitor...")
        monitor.stop()
        print("Monitor stopped")
